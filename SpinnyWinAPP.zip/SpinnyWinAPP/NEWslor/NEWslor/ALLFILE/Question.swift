//
//  Question.swift
//  NEWslor
//
//  Created by Shubham Parekh on 11/11/24.
//

import Foundation
struct Question {
    let text: String
    let options: [String]
    let correctAnswer: Int
    
    static let questions = [
        Question(text: "What is the capital of France?",
                options: ["London", "Paris", "Berlin", "Madrid"],
                correctAnswer: 1),
        Question(text: "Which planet is known as the Red Planet?",
                options: ["Venus", "Jupiter", "Mars", "Saturn"],
                correctAnswer: 2),
        Question(text: "Who painted the Mona Lisa?",
                options: ["Van Gogh", "Da Vinci", "Picasso", "Rembrandt"],
                correctAnswer: 1),
        Question(text: "What is the largest ocean on Earth?",
                options: ["Atlantic", "Indian", "Arctic", "Pacific"],
                correctAnswer: 3),
        Question(text: "Which element has the chemical symbol 'Au'?",
                options: ["Silver", "Gold", "Copper", "Aluminum"],
                correctAnswer: 1),
        Question(text: "What is the fastest land animal?",
                options: ["Lion", "Cheetah", "Gazelle", "Leopard"],
                correctAnswer: 1),
        Question(text: "Which country is home to the kangaroo?",
                options: ["New Zealand", "South Africa", "Australia", "India"],
                correctAnswer: 2),
        Question(text: "What is the largest organ in the human body?",
                options: ["Heart", "Brain", "Liver", "Skin"],
                correctAnswer: 3),
        Question(text: "Who wrote 'Romeo and Juliet'?",
                options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
                correctAnswer: 1),
        Question(text: "What is the capital of Japan?",
                options: ["Seoul", "Beijing", "Tokyo", "Bangkok"],
                correctAnswer: 2),
        Question(text: "Which year did World War II end?",
                options: ["1945", "1944", "1946", "1943"],
                correctAnswer: 0),
        Question(text: "What is the hardest natural substance on Earth?",
                options: ["Gold", "Iron", "Diamond", "Platinum"],
                correctAnswer: 2),
        Question(text: "Which is the longest river in the world?",
                options: ["Amazon", "Nile", "Mississippi", "Yangtze"],
                correctAnswer: 1),
        Question(text: "What is the main component of the Sun?",
                options: ["Helium", "Oxygen", "Hydrogen", "Nitrogen"],
                correctAnswer: 2),
        Question(text: "Who invented the telephone?",
                options: ["Thomas Edison", "Alexander Graham Bell", "Nikola Tesla", "Albert Einstein"],
                correctAnswer: 1),
        Question(text: "What is the capital of Brazil?",
                options: ["Rio de Janeiro", "São Paulo", "Brasília", "Salvador"],
                correctAnswer: 2),
        Question(text: "Which animal is known as the 'King of the Jungle'?",
                options: ["Tiger", "Lion", "Leopard", "Panther"],
                correctAnswer: 1),
        Question(text: "What is the smallest prime number?",
                options: ["0", "1", "2", "3"],
                correctAnswer: 2),
        Question(text: "Which continent is the largest?",
                options: ["North America", "Africa", "Asia", "Europe"],
                correctAnswer: 2),
        Question(text: "What percentage of the Earth's surface is water?",
                options: ["51%", "61%", "71%", "81%"],
                correctAnswer: 2)
    ]
}
