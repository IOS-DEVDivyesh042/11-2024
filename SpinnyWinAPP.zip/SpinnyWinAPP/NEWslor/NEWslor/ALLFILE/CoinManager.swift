import Foundation

class CoinManager {
    static let shared = CoinManager()
    private let coinKey = "userCoins"
    
    var currentCoins: Int {
        get {
            return UserDefaults.standard.integer(forKey: coinKey)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: coinKey)
        }
    }
    
    func addCoins(_ amount: Int) {
        currentCoins += amount
    }
    
    func removeCoins(_ amount: Int) {
        currentCoins = max(0, currentCoins - amount)
    }
}
