import UIKit

protocol BetControlDelegate: AnyObject {
    func didIncreaseBet()
    func didDecreaseBet()
}

class BetControlView: UIView {
    weak var delegate: BetControlDelegate?
    private var betLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupUI()
    }
    
    private func setupUI() {
        backgroundColor = UIColor.black.withAlphaComponent(0.3)
        layer.cornerRadius = 25
        
        let decreaseButton = UIButton(type: .system)
        decreaseButton.translatesAutoresizingMaskIntoConstraints = false
        decreaseButton.setTitle("-", for: .normal)
        decreaseButton.titleLabel?.font = .systemFont(ofSize: 24, weight: .bold)
        decreaseButton.setTitleColor(.white, for: .normal)
        decreaseButton.addTarget(self, action: #selector(decreaseButtonTapped), for: .touchUpInside)
        
        let increaseButton = UIButton(type: .system)
        increaseButton.translatesAutoresizingMaskIntoConstraints = false
        increaseButton.setTitle("+", for: .normal)
        increaseButton.titleLabel?.font = .systemFont(ofSize: 24, weight: .bold)
        increaseButton.setTitleColor(.white, for: .normal)
        increaseButton.addTarget(self, action: #selector(increaseButtonTapped), for: .touchUpInside)
        
        betLabel = UILabel()
        betLabel.translatesAutoresizingMaskIntoConstraints = false
        betLabel.textColor = .white
        betLabel.font = .systemFont(ofSize: 20, weight: .bold)
        betLabel.textAlignment = .center
        updateBetLabel(with: GameState.shared.currentBet)
        
        addSubview(decreaseButton)
        addSubview(betLabel)
        addSubview(increaseButton)
        
        NSLayoutConstraint.activate([
            decreaseButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            decreaseButton.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            betLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            betLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            increaseButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            increaseButton.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    @objc private func decreaseButtonTapped() {
        delegate?.didDecreaseBet()
    }
    
    @objc private func increaseButtonTapped() {
        delegate?.didIncreaseBet()
    }
    
    func updateBetLabel(with bet: Int) {
        betLabel.text = "Bet: \(bet)"
    }
}
