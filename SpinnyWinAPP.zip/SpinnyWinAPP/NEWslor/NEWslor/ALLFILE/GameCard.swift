//
//  GameCard.swift
//  NEWslor
//
//  Created by Shubham Parekh on 12/11/24.
//

import Foundation

struct GameCard {
    let id: UUID
    let symbol: String // Unicode symbol for the card's front
    var isFlipped: Bool = false
    var isMatched: Bool = false
}
