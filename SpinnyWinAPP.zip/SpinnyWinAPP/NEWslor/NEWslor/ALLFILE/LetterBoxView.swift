import UIKit

class LetterBoxView: UIView {
    private let textField: UITextField = {
        let tf = UITextField()
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.textAlignment = .center
        tf.font = .systemFont(ofSize: 24, weight: .bold)
        tf.backgroundColor = .systemBackground
        tf.layer.borderWidth = 2
        tf.layer.borderColor = UIColor.systemGray3.cgColor
        tf.layer.cornerRadius = 8
        return tf
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        addSubview(textField)
        
        NSLayoutConstraint.activate([
            textField.topAnchor.constraint(equalTo: topAnchor),
            textField.leadingAnchor.constraint(equalTo: leadingAnchor),
            textField.trailingAnchor.constraint(equalTo: trailingAnchor),
            textField.bottomAnchor.constraint(equalTo: bottomAnchor),
            textField.heightAnchor.constraint(equalTo: textField.widthAnchor)
        ])
        
        textField.delegate = self
    }
    
    var letter: String? {
        get { return textField.text }
        set { textField.text = newValue }
    }
    
    func setNextField(_ field: LetterBoxView?) {
        textField.returnKeyType = field == nil ? .done : .next
        nextField = field
    }
    
    private var nextField: LetterBoxView?
}

extension LetterBoxView: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentText = textField.text ?? ""
        guard let stringRange = Range(range, in: currentText) else { return false }
        let updatedText = currentText.replacingCharacters(in: stringRange, with: string)
        
        if updatedText.count <= 1 {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.nextField?.textField.becomeFirstResponder()
            }
            return true
        }
        return false
    }
}
