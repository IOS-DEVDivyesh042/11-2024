import UIKit

class TrophyView: UIView {
    private let trophyLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "🏆"
        label.font = .systemFont(ofSize: 60)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        addSubview(trophyLabel)
        
        NSLayoutConstraint.activate([
            trophyLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            trophyLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    func animate() {
        transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5) {
            self.transform = .identity
        }
    }
}
