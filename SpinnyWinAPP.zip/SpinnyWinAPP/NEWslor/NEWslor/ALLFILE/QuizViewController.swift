//
//  QuizViewController.swift
//  NEWslor
//
//  Created by Shubham Parekh on 11/11/24.
//

import UIKit

class QuizViewController: UIViewController {
    // UI Elements
    private let progressBar: UIProgressView = {
        let progress = UIProgressView(progressViewStyle: .default)
        progress.translatesAutoresizingMaskIntoConstraints = false
        progress.progressTintColor = .systemGreen
        progress.trackTintColor = .systemGray5
        return progress
    }()
    
    private let questionLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 24, weight: .bold)
        label.textColor = .white
        label.numberOfLines = 0
        label.textAlignment = .center
        label.backgroundColor = UIColor(white: 1, alpha: 0.15)
        label.layer.cornerRadius = 12
        label.clipsToBounds = true
        return label
    }()
    
    private let optionsStackView: UIStackView = {
        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .vertical
        stack.spacing = 16
        stack.distribution = .fillEqually
        return stack
    }()
    
    // Properties
    private var timer: Timer?
    private var currentQuestionIndex = 0
    private var correctAnswers = 0
    private var questions: [Question] = []
    private var optionButtons: [UIButton] = []
    
    private let gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer()
        layer.colors = [
            UIColor(red: 0.1, green: 0.0, blue: 0.3, alpha: 1.0).cgColor,
            UIColor(red: 0.2, green: 0.0, blue: 0.6, alpha: 1.0).cgColor,
            UIColor(red: 0.0, green: 0.2, blue: 0.8, alpha: 1.0).cgColor
        ]
        layer.locations = [0.0, 0.5, 1.0]
        layer.startPoint = CGPoint(x: 0.0, y: 0.0)
        layer.endPoint = CGPoint(x: 1.0, y: 1.0)
        return layer
    }()
    
    // Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        startQuiz()
        setupCoinCounter()
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    // Setup Methods
    private func setupUI() {
       // setupGradientBackground()
        setupConstraints()
        setupOptionButtons()
    }
    
    private func setupGradientBackground() {
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    private func setupConstraints() {
        view.addSubview(progressBar)
        view.addSubview(questionLabel)
        view.addSubview(optionsStackView)
        
        NSLayoutConstraint.activate([
            progressBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            progressBar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            progressBar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            
            
            questionLabel.topAnchor.constraint(equalTo: progressBar.bottomAnchor, constant: 60),
            questionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            questionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            
            optionsStackView.topAnchor.constraint(equalTo: questionLabel.bottomAnchor, constant: 32),
            optionsStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            optionsStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            optionsStackView.bottomAnchor.constraint(lessThanOrEqualTo: view.bottomAnchor, constant: -32)
        ])
    }
    
    private func setupOptionButtons() {
        for _ in 0..<4 {
            let button = UIButton()
            button.backgroundColor = UIColor(white: 1, alpha: 0.75)
            button.layer.cornerRadius = 8
            button.titleLabel?.font = .systemFont(ofSize: 18)
            button.addTarget(self, action: #selector(optionTapped(_:)), for: .touchUpInside)
            optionsStackView.addArrangedSubview(button)
            optionButtons.append(button)
        }
    }
    
    // Game Logic
    private func startQuiz() {
        questions = Question.questions.shuffled()
        showQuestion()
        startTimer()
    }
    
    private func showQuestion() {
        let question = questions[currentQuestionIndex]
        questionLabel.text = question.text
        
        for (index, button) in optionButtons.enumerated() {
            button.setTitle(question.options[index], for: .normal)
        }
        
        progressBar.progress = 0
        startTimer()
    }
    
    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] timer in
            guard let self = self else { return }
            let progress = self.progressBar.progress + 0.1/30
            self.progressBar.progress = progress
            if progress >= 1 {
                self.moveToNextQuestion()
            }
        }
    }
    
    @objc private func optionTapped(_ sender: UIButton) {
        guard let index = optionButtons.firstIndex(of: sender),
              currentQuestionIndex < questions.count else { return }
        
        if index == questions[currentQuestionIndex].correctAnswer {
            correctAnswers += 1
            sender.backgroundColor = .systemGreen
        } else {
            sender.backgroundColor = .systemRed
            optionButtons[questions[currentQuestionIndex].correctAnswer].backgroundColor = .systemGreen
        }
        
        // Delay before moving to next question to show correct/wrong answer
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            self?.moveToNextQuestion()
            self?.optionButtons.forEach { $0.backgroundColor = UIColor(white: 1, alpha: 0.75) }
        }
    }

    
    private func moveToNextQuestion() {
        timer?.invalidate()
        currentQuestionIndex += 1
        
        if currentQuestionIndex >= questions.count {
            showResults()
        } else {
            showQuestion()
        }
    }
    
    private func showResults() {
        let earnedCoins = correctAnswers * 100
        CoinManager.shared.addCoins(earnedCoins)
        
        let popupView = createResultPopup(earnedCoins: earnedCoins)
        view.addSubview(popupView)
        
        NSLayoutConstraint.activate([
            popupView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            popupView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            popupView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            popupView.heightAnchor.constraint(equalToConstant: 400)
        ])
    }
    
    private func createResultPopup(earnedCoins: Int) -> UIView {
        let popupView = UIView()
        popupView.backgroundColor = UIColor(white: 1, alpha: 0.95)
        popupView.layer.cornerRadius = 20
        popupView.translatesAutoresizingMaskIntoConstraints = false
        
        // Add components to popup
        setupPopupComponents(popupView: popupView, earnedCoins: earnedCoins)
        
        return popupView
    }
    
    private func setupPopupComponents(popupView: UIView, earnedCoins: Int) {
        // Trophy
        let trophyImageView = createTrophyImageView()
        
        // Score Label
        let scoreLabel = createScoreLabel(earnedCoins: earnedCoins)
        
        // Buttons
        let (restartButton, homeButton) = createPopupButtons()
        
        // Add to popup
        popupView.addSubview(trophyImageView)
        popupView.addSubview(scoreLabel)
        popupView.addSubview(restartButton)
        popupView.addSubview(homeButton)
        
        // Constraints
        NSLayoutConstraint.activate([
            trophyImageView.topAnchor.constraint(equalTo: popupView.topAnchor, constant: 20),
            trophyImageView.centerXAnchor.constraint(equalTo: popupView.centerXAnchor),
            trophyImageView.heightAnchor.constraint(equalToConstant: 120),
            trophyImageView.widthAnchor.constraint(equalToConstant: 120),
            
            scoreLabel.topAnchor.constraint(equalTo: trophyImageView.bottomAnchor, constant: 20),
            scoreLabel.leadingAnchor.constraint(equalTo: popupView.leadingAnchor, constant: 20),
            scoreLabel.trailingAnchor.constraint(equalTo: popupView.trailingAnchor, constant: -20),
            
            restartButton.leadingAnchor.constraint(equalTo: popupView.leadingAnchor, constant: 20),
            restartButton.bottomAnchor.constraint(equalTo: popupView.bottomAnchor, constant: -20),
            restartButton.heightAnchor.constraint(equalToConstant: 50),
            restartButton.widthAnchor.constraint(equalTo: popupView.widthAnchor, multiplier: 0.4),
            
            homeButton.trailingAnchor.constraint(equalTo: popupView.trailingAnchor, constant: -20),
            homeButton.bottomAnchor.constraint(equalTo: popupView.bottomAnchor, constant: -20),
            homeButton.heightAnchor.constraint(equalToConstant: 50),
            homeButton.widthAnchor.constraint(equalTo: popupView.widthAnchor, multiplier: 0.4)
        ])
    }
    
    private func createTrophyImageView() -> UIImageView {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        
        let configuration = UIImage.SymbolConfiguration(pointSize: 80, weight: .bold)
        if correctAnswers >= 15 {
            imageView.image = UIImage(systemName: "trophy.fill", withConfiguration: configuration)
            imageView.tintColor = .systemYellow
        } else if correctAnswers >= 10 {
            imageView.image = UIImage(systemName: "medal.fill", withConfiguration: configuration)
            imageView.tintColor = .systemOrange
        } else {
            imageView.image = UIImage(systemName: "tortoise.fill", withConfiguration: configuration)
            imageView.tintColor = .systemGray
        }
        return imageView
    }
    
    private func createScoreLabel(earnedCoins: Int) -> UILabel {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = """
            Score: \(correctAnswers)/\(questions.count)
            Earned Coins: \(earnedCoins)
            """
        label.numberOfLines = 0
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 20, weight: .bold)
        return label
    }
    
    private func createPopupButtons() -> (UIButton, UIButton) {
        let restartButton = UIButton()
        restartButton.translatesAutoresizingMaskIntoConstraints = false
        restartButton.setTitle("Play Again", for: .normal)
        restartButton.backgroundColor = .systemBlue
        restartButton.layer.cornerRadius = 10
        restartButton.addTarget(self, action: #selector(restartQuiz), for: .touchUpInside)
        
        let homeButton = UIButton()
        homeButton.translatesAutoresizingMaskIntoConstraints = false
        homeButton.setTitle("Home", for: .normal)
        homeButton.backgroundColor = .systemGreen
        homeButton.layer.cornerRadius = 10
        homeButton.addTarget(self, action: #selector(goToHome), for: .touchUpInside)
        
        return (restartButton, homeButton)
    }
    
    @objc private func restartQuiz() {
        view.subviews.last?.removeFromSuperview()
        currentQuestionIndex = 0
        correctAnswers = 0
        startQuiz()
    }
    
    @objc private func goToHome() {
        if let navigationController = navigationController {
               navigationController.popToRootViewController(animated: true)
           } else {
               dismiss(animated: true)
           }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gradientLayer.frame = view.bounds
    }
    
    private let coinView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor(white: 1, alpha: 0.15)
        view.layer.cornerRadius = 20
        return view
    }()

    private let coinImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(systemName: "dollarsign.circle.fill")
        imageView.tintColor = .systemYellow
        return imageView
    }()

    private let coinLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 18, weight: .bold)
        label.textColor = .white
        label.text = "\(CoinManager.shared.currentCoins)"
        return label
    }()

    // Add this to your setupUI method
    private func setupCoinCounter() {
        view.addSubview(coinView)
        coinView.addSubview(coinImageView)
        coinView.addSubview(coinLabel)
        
        NSLayoutConstraint.activate([
            coinView.topAnchor.constraint(equalTo: progressBar.bottomAnchor, constant: 8),
            coinView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            coinView.heightAnchor.constraint(equalToConstant: 40),
            coinView.widthAnchor.constraint(greaterThanOrEqualToConstant: 100),
            
            coinImageView.leadingAnchor.constraint(equalTo: coinView.leadingAnchor, constant: 12),
            coinImageView.centerYAnchor.constraint(equalTo: coinView.centerYAnchor),
            coinImageView.heightAnchor.constraint(equalToConstant: 24),
            coinImageView.widthAnchor.constraint(equalToConstant: 24),
            
            coinLabel.leadingAnchor.constraint(equalTo: coinImageView.trailingAnchor, constant: 8),
            coinLabel.trailingAnchor.constraint(equalTo: coinView.trailingAnchor, constant: -12),
            coinLabel.centerYAnchor.constraint(equalTo: coinView.centerYAnchor)
        ])
    }
    
    private func updateCoinDisplay() {
        coinLabel.text = "\(CoinManager.shared.currentCoins)"
    }
    
}
