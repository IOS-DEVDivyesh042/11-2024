//
//  GameResult.swift
//  NEWslor
//
//  Created by Shubham Parekh on 11/11/24.
//

import Foundation
struct GameResult {
    let correctAnswers: Int
    let totalQuestions: Int
    let earnedCoins: Int
    
    var percentage: Double {
        return Double(correctAnswers) / Double(totalQuestions) * 100
    }
    
    var trophyType: TrophyType {
        if correctAnswers >= 15 {
            return .excellent
        } else if correctAnswers >= 10 {
            return .good
        } else {
            return .duck
        }
    }
}

enum TrophyType {
    case excellent
    case good
    case duck
    
    var imageName: String {
        switch self {
        case .excellent: return "trophy.excellent"
        case .good: return "trophy.good"
        case .duck: return "duck"
        }
    }
}
