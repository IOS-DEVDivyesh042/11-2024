//
//  Word.swift
//  NEWslor
//
//  Created by Shubham Parekh on 11/11/24.
//

import Foundation
struct FruitWord {
    static let fruitList = [
        "APPLE",
        "BANANA",
        "CHERRY",
        "DRAGON",
        "ELDERBERRY",
        "FIG",
        "GRAPE",
        "HONEYDEW",
        "IMBE",
        "JACKFRUIT",
        "KIWI",
        "LEMON",
        "MANGO",
        "NECTARINE",
        "ORANGE",
        "PAPAYA",
        "QUINCE",
        "RASPBERRY",
        "STRAWBERRY",
        "TANGERINE",
        "UGLI",
        "VOAVANGA",
        "WATERMELON",
        "XIMENIA",
        "YUZU",
        "ZIZIPHUS"
    ]
    
    static func getRandomFruit() -> String {
        return fruitList.randomElement() ?? "APPLE"
    }
}
