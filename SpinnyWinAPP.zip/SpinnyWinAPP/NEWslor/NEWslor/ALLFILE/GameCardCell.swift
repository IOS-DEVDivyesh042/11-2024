import UIKit

class GameCardCell: UICollectionViewCell {
    static let reuseIdentifier = "GameCardCell"
    private var symbolLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        // Setup the symbol label
        symbolLabel = UILabel(frame: .zero)
        symbolLabel.font = UIFont.systemFont(ofSize: 36)
        symbolLabel.textAlignment = .center
        symbolLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(symbolLabel)
        
        // Layout constraints
        NSLayoutConstraint.activate([
            symbolLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            symbolLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            symbolLabel.topAnchor.constraint(equalTo: contentView.topAnchor),
            symbolLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
        
        // Cell appearance
        contentView.layer.cornerRadius = 8
        contentView.layer.masksToBounds = true
        contentView.layer.borderWidth = 1
        contentView.layer.borderColor = UIColor.white.cgColor
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(with card: GameCard) {
        // Show the card front if flipped or matched, otherwise show "?" for back
        symbolLabel.text = (card.isFlipped || card.isMatched) ? card.symbol : "❓"
    }
}
