//import Foundation
//
//class CoinManager {
//    static let shared = CoinManager()
//    private let coinKey = "userCoins"
//    
//    var currentCoins: Int {
//        get {
//            return UserDefaults.standard.integer(forKey: coinKey)
//        }
//        set {
//            UserDefaults.standard.set(newValue, forKey: coinKey)
//        }
//    }
//    
//    func addCoins(_ amount: Int) {
//        currentCoins += amount
//    }
//    
//    func removeCoins(_ amount: Int) {
//        currentCoins = max(0, currentCoins - amount)
//    }
//}
import Foundation

class CoinManager {
    static let shared = CoinManager()
    private let coinKey = "userCoins"
    
    var currentCoins: Int {
        get {
            // Check if the key exists in UserDefaults
            if UserDefaults.standard.value(forKey: coinKey) == nil {
                // If no value is found, this is the first launch, so set coins to 100
                UserDefaults.standard.set(1000, forKey: coinKey)
                return 1000
            }
            return UserDefaults.standard.integer(forKey: coinKey)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: coinKey)
        }
    }
    
    func addCoins(_ amount: Int) {
        currentCoins += amount
    }
    
    func removeCoins(_ amount: Int) {
        currentCoins = max(0, currentCoins - amount)
    }
}
