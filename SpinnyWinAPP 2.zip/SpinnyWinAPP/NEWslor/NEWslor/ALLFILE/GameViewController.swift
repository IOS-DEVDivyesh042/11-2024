import UIKit

class GameViewController: UIViewController {
    
    // MARK: - Properties
    private var letterBoxes: [LetterBoxView] = []
    private var currentWord: String = ""
    
    private let coinContainerView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .white
        view.layer.cornerRadius = 10
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.3
        view.layer.opacity = 0.90
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        return view
    }()
    
    // MARK: - UI Elements
    private let coinLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = .systemYellow
        label.backgroundColor = .white
       
        label.font = .systemFont(ofSize: 24, weight: .bold)
        return label
    }()
    
    private let wordLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 24, weight: .bold)
        label.textAlignment = .center
        label.textColor = .white
        return label
    }()
    
    private let boxesStackView: UIStackView = {
        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .horizontal
        stack.spacing = 8
        stack.distribution = .fillEqually
        return stack
    }()
    
    private lazy var checkButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Check Answer", for: .normal)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(checkButtonTapped), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
        coinLabel.layer.cornerRadius = 4
      //  setupGradientBackground()
        setupInitialCoins()
        setupUI()
        startNewGame()
    }
    
    

    
    // MARK: - Setup Methods
    private func setupInitialCoins() {
        if CoinManager.shared.currentCoins == 0 {
            CoinManager.shared.addCoins(1000)
        }
        updateCoinLabel()
    }
    
    private func setupUI() {
        view.backgroundColor = .systemBackground
        
        view.addSubview(coinContainerView)
        coinContainerView.addSubview(coinLabel)
        view.addSubview(wordLabel)
        view.addSubview(boxesStackView)
        view.addSubview(checkButton)
        
        NSLayoutConstraint.activate([
            // Coin Container View Constraints
            coinContainerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            coinContainerView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            coinContainerView.widthAnchor.constraint(equalToConstant: 120),
            coinContainerView.heightAnchor.constraint(equalToConstant: 50),
            
            // Coin Label Constraints (Inside the Container View)
            coinLabel.centerXAnchor.constraint(equalTo: coinContainerView.centerXAnchor),
            coinLabel.centerYAnchor.constraint(equalTo: coinContainerView.centerYAnchor),
            coinLabel.leadingAnchor.constraint(equalTo: coinContainerView.leadingAnchor, constant: 8),
            coinLabel.trailingAnchor.constraint(equalTo: coinContainerView.trailingAnchor, constant: -8),
            
            // Word Label Constraints
            wordLabel.topAnchor.constraint(equalTo: coinContainerView.bottomAnchor, constant: 32),
            wordLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            wordLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            
            // Boxes Stack View Constraints
            boxesStackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            boxesStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            boxesStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            // Check Button Constraints
            checkButton.topAnchor.constraint(equalTo: boxesStackView.bottomAnchor, constant: 32),
            checkButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            checkButton.widthAnchor.constraint(equalToConstant: 200),
            checkButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    
    private func startNewGame() {
        if CoinManager.shared.currentCoins < 100 {
            showInsufficientCoinsPopup()
            return
        }
        
        currentWord = FruitWord.getRandomFruit()
        let scrambledWord = String(currentWord.shuffled())
        wordLabel.text = "Unscramble: \(scrambledWord)"
        
        letterBoxes.forEach { $0.removeFromSuperview() }
        letterBoxes.removeAll()
        setupLetterBoxes()
    }
    
    private func setupLetterBoxes() {
        for _ in 0..<currentWord.count {
            let box = LetterBoxView()
            letterBoxes.append(box)
            boxesStackView.addArrangedSubview(box)
        }
        
        for i in 0..<letterBoxes.count {
            if i < letterBoxes.count - 1 {
                letterBoxes[i].setNextField(letterBoxes[i + 1])
            } else {
                letterBoxes[i].setNextField(nil)
            }
        }
        
        letterBoxes.first?.becomeFirstResponder()
    }
    private let gradientLayer: CAGradientLayer = {
            let layer = CAGradientLayer()
            layer.colors = [
                UIColor(red: 0.1, green: 0.05, blue: 0.3, alpha: 1.0).cgColor,
                UIColor(red: 0.2, green: 0.1, blue: 0.4, alpha: 1.0).cgColor,
                UIColor(red: 0.3, green: 0.15, blue: 0.5, alpha: 1.0).cgColor
            ]
            layer.startPoint = CGPoint(x: 0.0, y: 0.0)
            layer.endPoint = CGPoint(x: 1.0, y: 1.0)
            return layer
        }()

        private func setupGradientBackground() {
            gradientLayer.frame = view.bounds
            view.layer.insertSublayer(gradientLayer, at: 0)
            animateGradient()
        }

        private func animateGradient() {
            let animation = CABasicAnimation(keyPath: "colors")
            animation.duration = 3.0
            animation.autoreverses = true
            animation.repeatCount = .infinity
            animation.fromValue = gradientLayer.colors
            animation.toValue = [
                UIColor(red: 0.3, green: 0.15, blue: 0.5, alpha: 1.0).cgColor,
                UIColor(red: 0.2, green: 0.1, blue: 0.4, alpha: 1.0).cgColor,
                UIColor(red: 0.1, green: 0.05, blue: 0.3, alpha: 1.0).cgColor
            ]
            gradientLayer.add(animation, forKey: "gradientAnimation")
        }
    
    private func updateCoinLabel() {
        coinLabel.text = "💰 \(CoinManager.shared.currentCoins)"
    }
    
    // MARK: - Actions
    @objc private func checkButtonTapped() {
        let enteredWord = letterBoxes.compactMap { $0.letter }.joined().uppercased()
        
        if enteredWord.count != currentWord.count {
            showAlert(title: "Incomplete", message: "Please fill all letters")
            return
        }
        
        if enteredWord == currentWord {
            CoinManager.shared.addCoins(1000)
            updateCoinLabel()
            showWinPopup()
        } else {
            CoinManager.shared.removeCoins(100)
            updateCoinLabel()
            showLosePopup()
        }
    }
    
    // MARK: - Alert Methods
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    private func showInsufficientCoinsPopup() {
        let popup = ResultPopupView(
            title: "Insufficient Coins",
            message: "You need at least 100 coins to play. Current balance: \(CoinManager.shared.currentCoins)"
        ) {
            self.dismiss(animated: true)
        }
        view.addSubview(popup)
        popup.frame = view.bounds
    }
    
    private func showWinPopup() {
        let trophyView = TrophyView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        let popup = ResultPopupView(
            title: "Congratulations!",
            message: "You won! 1000 coins added to your wallet."
        ) {
            self.startNewGame()
        }
        popup.addTrophyView(trophyView)
        view.addSubview(popup)
        popup.frame = view.bounds
        trophyView.animate()
    }
    
    private func showLosePopup() {
        let popup = ResultPopupView(
            title: "Game Over",
            message: "The correct word was: \(currentWord)\n100 coins deducted."
        ) {
            self.startNewGame()
        }
        view.addSubview(popup)
        popup.frame = view.bounds
    }
}
