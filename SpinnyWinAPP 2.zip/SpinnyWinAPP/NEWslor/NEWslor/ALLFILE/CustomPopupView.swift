import UIKit

class CustomPopupView: UIView {
    private let trophyImageView = UIImageView()
    private let scoreLabel = UILabel()
    private let closeButton = UIButton(type: .system)
    
    var closeAction: (() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        backgroundColor = .white
        layer.cornerRadius = 16
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.3
        layer.shadowOffset = CGSize(width: 0, height: 5)
        layer.shadowRadius = 10
        
        // Trophy Image
        trophyImageView.image = UIImage(systemName: "trophy.fill") // System trophy icon
        trophyImageView.tintColor = .systemYellow
        trophyImageView.contentMode = .scaleAspectFit
        trophyImageView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(trophyImageView)
        
        // Score Label
        scoreLabel.font = .systemFont(ofSize: 24, weight: .bold)
        scoreLabel.textAlignment = .center
        scoreLabel.numberOfLines = 0
        scoreLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(scoreLabel)
        
        // Close Button
        closeButton.setTitle("Close", for: .normal)
        closeButton.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        closeButton.addTarget(self, action: #selector(closeButtonTapped), for: .touchUpInside)
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        addSubview(closeButton)
        
        // Layout
        NSLayoutConstraint.activate([
            trophyImageView.topAnchor.constraint(equalTo: topAnchor, constant: 20),
            trophyImageView.centerXAnchor.constraint(equalTo: centerXAnchor),
            trophyImageView.heightAnchor.constraint(equalToConstant: 80),
            trophyImageView.widthAnchor.constraint(equalToConstant: 80),
            
            scoreLabel.topAnchor.constraint(equalTo: trophyImageView.bottomAnchor, constant: 20),
            scoreLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            scoreLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            
            closeButton.topAnchor.constraint(equalTo: scoreLabel.bottomAnchor, constant: 20),
            closeButton.centerXAnchor.constraint(equalTo: centerXAnchor),
            closeButton.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -20)
        ])
    }
    
    func configure(with score: Int, total: Int) {
        scoreLabel.text = "Your Score: \(score)/\(total)"
    }
    
    @objc private func closeButtonTapped() {
        closeAction?()
    }
}
