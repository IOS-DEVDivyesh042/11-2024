import UIKit

class MemoryGameViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    private var collectionView: UICollectionView!
    private var cards: [GameCard] = []
    private var flippedCards: [IndexPath] = []
    private var score = 0
    private var gridSize = 4 // Starting with 4x4 grid
    
    private var scoreLabel: UILabel!
    private var coinLabel: UILabel!
    private var coinImageView: UIImageView!
    var deck: [GameCard] = []
    override func viewDidLoad() {
        super.viewDidLoad()
       // view.backgroundColor = .white
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
        setupLabels()
        setupCollectionView()
        setupNewGame(gridSize: gridSize)
        deck = createDeck(size: 32)
        
    }

    // MARK: - Setup Methods
    private func setupLabels() {
        // Coin Label Container (Background View)
        let coinLabelContainer = UIView()
        coinLabelContainer.backgroundColor = .white
        coinLabelContainer.layer.cornerRadius = 10
        coinLabelContainer.layer.masksToBounds = true
        coinLabelContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(coinLabelContainer)
        
        // Coin Label
        coinLabel = UILabel()
        coinLabel.text = "💰 \(CoinManager.shared.currentCoins)"
        coinLabel.font = UIFont.systemFont(ofSize: 18)
        coinLabel.textColor = .black
        coinLabel.translatesAutoresizingMaskIntoConstraints = false
        coinLabelContainer.addSubview(coinLabel)
        
        // Score Label Container (Background View)
        let scoreLabelContainer = UIView()
        scoreLabelContainer.backgroundColor = .white
        scoreLabelContainer.layer.cornerRadius = 10
        scoreLabelContainer.layer.masksToBounds = true
        scoreLabelContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scoreLabelContainer)
        
        // Score Label
        scoreLabel = UILabel()
        scoreLabel.text = "Score: \(score)"
        scoreLabel.font = UIFont.systemFont(ofSize: 18)
        scoreLabel.textColor = .black
        scoreLabel.translatesAutoresizingMaskIntoConstraints = false
        scoreLabelContainer.addSubview(scoreLabel)
        
        // Constraints for Coin Label Container
        NSLayoutConstraint.activate([
            coinLabelContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            coinLabelContainer.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
            coinLabelContainer.heightAnchor.constraint(equalToConstant: 50),
            coinLabelContainer.widthAnchor.constraint(equalToConstant: 100),
            
            // Coin Label constraints inside the coin label container
            coinLabel.topAnchor.constraint(equalTo: coinLabelContainer.topAnchor, constant: 5),
            coinLabel.leadingAnchor.constraint(equalTo: coinLabelContainer.leadingAnchor, constant: 10),
            coinLabel.trailingAnchor.constraint(equalTo: coinLabelContainer.trailingAnchor, constant: -10),
            coinLabel.bottomAnchor.constraint(equalTo: coinLabelContainer.bottomAnchor, constant: -5),
        ])
        
        // Constraints for Score Label Container
        NSLayoutConstraint.activate([
            scoreLabelContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            scoreLabelContainer.topAnchor.constraint(equalTo: view.topAnchor, constant: 50),
            scoreLabelContainer.heightAnchor.constraint(equalToConstant: 50),
            scoreLabelContainer.widthAnchor.constraint(equalToConstant: 100),
            
            // Score Label constraints inside the score label container
            scoreLabel.topAnchor.constraint(equalTo: scoreLabelContainer.topAnchor, constant: 5),
            scoreLabel.leadingAnchor.constraint(equalTo: scoreLabelContainer.leadingAnchor, constant: 10),
            scoreLabel.trailingAnchor.constraint(equalTo: scoreLabelContainer.trailingAnchor, constant: -10),
            scoreLabel.bottomAnchor.constraint(equalTo: scoreLabelContainer.bottomAnchor, constant: -5),
        ])
    }


    private func setupCollectionView() {
        // Setup collection view layout
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        
        // Initialize collection view
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.register(GameCardCell.self, forCellWithReuseIdentifier: GameCardCell.reuseIdentifier)
        collectionView.dataSource = self
        collectionView.delegate = self
        view.addSubview(collectionView)
        
        // Set up constraints for collection view
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            collectionView.topAnchor.constraint(equalTo: coinLabel.bottomAnchor, constant: 20),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -50)
        ])
    }

    // Start a new game
    func setupNewGame(gridSize: Int) {
        cards = createDeck(size: gridSize * gridSize / 2)
        collectionView.reloadData()
        score = 0
        updateLabels()
    }

    // Create a deck of card pairs with unique symbols
    func createDeck(size: Int) -> [GameCard] {
        let symbols = ["👑", "🤴", "👸", "💰", "🏴‍☠️", "⚓", "🏝️", "💎", "🗡️", "💀", "🦜", "🦈", "⛵", "🌊", "🔥", "🍖"] // Pirate symbols
        var deck = [GameCard]()
        
        for i in 0..<size {
            let card1 = GameCard(id: UUID(), symbol: symbols[i % symbols.count])
            let card2 = GameCard(id: UUID(), symbol: symbols[i % symbols.count])
            deck.append(contentsOf: [card1, card2])
        }
        
        return deck.shuffled()
    }

    private func updateLabels() {
        scoreLabel.text = "Score: \(score)"
        coinLabel.text = "💰 \(CoinManager.shared.currentCoins)"
    }

    // MARK: - UICollectionView DataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cards.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: GameCardCell.reuseIdentifier, for: indexPath) as! GameCardCell
        let card = cards[indexPath.item]
        cell.configure(with: card)
        return cell
    }

    // MARK: - UICollectionView Delegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var card = cards[indexPath.item]
        
        if card.isFlipped || card.isMatched {
            return
        }
        
        card.isFlipped = true
        cards[indexPath.item] = card
        collectionView.reloadItems(at: [indexPath])
        
        flippedCards.append(indexPath)
        
        if flippedCards.count == 2 {
            checkForMatch()
        }
    }

    private func checkForMatch() {
        let firstIndex = flippedCards[0]
        let secondIndex = flippedCards[1]
        
        if cards[firstIndex.item].symbol == cards[secondIndex.item].symbol {
            cards[firstIndex.item].isMatched = true
            cards[secondIndex.item].isMatched = true
            score += 10
            CoinManager.shared.addCoins(5) // Add 5 coins for a match
            checkGameCompletion()
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.cards[firstIndex.item].isFlipped = false
                self.cards[secondIndex.item].isFlipped = false
                self.collectionView.reloadItems(at: [firstIndex, secondIndex])
            }
        }
        
        flippedCards.removeAll()
        updateLabels()
    }

    private func checkGameCompletion() {
        if cards.allSatisfy({ $0.isMatched }) {
            let alert = UIAlertController(title: "Congratulations!", message: "Level Completed!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Next Level", style: .default) { _ in
                self.gridSize += 1
                self.setupNewGame(gridSize: self.gridSize)
            })
            present(alert, animated: true, completion: nil)
        }
    }

    // MARK: - UICollectionView DelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let columns: CGFloat = CGFloat(gridSize)
        let spacing: CGFloat = 10 * (columns - 1)
        let totalWidth = collectionView.bounds.width - spacing
        let width = totalWidth / columns
        return CGSize(width: width, height: width)
    }
}
