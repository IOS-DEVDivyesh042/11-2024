//
//  ViewController.swift
//  NEWslor
//
//  Created by Shubham Parekh on 10/11/24.
//

import UIKit
import StoreKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var v1: UIView!
    
    
    @IBOutlet weak var v2in: UIView!
    
    @IBOutlet weak var v2: UIView!
    
    @IBOutlet weak var v1in: UIView!
    
    @IBOutlet weak var v3: UIView!
    
    @IBOutlet weak var v3in: UIView!
    
    @IBOutlet weak var v4in: UIView!
    
    @IBOutlet weak var v4: UIView!
    
    @IBOutlet weak var vwabt: UIView!
    
    @IBOutlet weak var vert: UIView!
    
    @IBOutlet weak var vwfd: UIView!
    
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        callpass()
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
        // Do any additional setup after loading the view.
    }
    
    
    func callpass(){
        vwabt.layer.cornerRadius = 20
        vert.layer.cornerRadius = 20
        vwfd.layer.cornerRadius = 20
        v1.layer.cornerRadius = 10
        v2.layer.cornerRadius = 10
        v3.layer.cornerRadius = 10
        v4.layer.cornerRadius = 10
        v1in.layer.cornerRadius = 10
        v2in.layer.cornerRadius = 10
        v3in.layer.cornerRadius = 10
        v4in.layer.cornerRadius = 10
        
    }
    
    @IBAction func btnrate(_ sender: Any) {
        if let windowScene = view.window?.windowScene { SKStoreReviewController.requestReview(in: windowScene) }

    }
    

    

}

