//import UIKit
//class CustomSlotMachineViewController: UIViewController {
//    
//    var totalCoins = 1000
//    var coinLabel: UILabel!
//    var spinButton: UIButton!
//    var reels: [ReelView] = []
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        // Set up the view background
//        view.backgroundColor = .lightGray
//        
//        // Set up total coins label
//        setupCoinLabel()
//        
//        // Set up Spin button
//        setupSpinButton()
//        
//        // Set up Slot Machine grid (4x4)
//        setupReels()
//    }
//    
//    // MARK: - Set up Coin Label
//    func setupCoinLabel() {
//        coinLabel = UILabel()
//        coinLabel.text = "Coins: \(totalCoins)"
//        coinLabel.font = UIFont.boldSystemFont(ofSize: 24)
//        coinLabel.textColor = .black
//        coinLabel.textAlignment = .center
//        coinLabel.translatesAutoresizingMaskIntoConstraints = false
//        view.addSubview(coinLabel)
//        
//        NSLayoutConstraint.activate([
//            coinLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 40),
//            coinLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
//        ])
//    }
//    
//    // MARK: - Set up Spin Button
//    func setupSpinButton() {
//        spinButton = UIButton(type: .system)
//        spinButton.setTitle("Spin", for: .normal)
//        spinButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
//        spinButton.backgroundColor = .blue
//        spinButton.setTitleColor(.white, for: .normal)
//        spinButton.layer.cornerRadius = 10
//        spinButton.translatesAutoresizingMaskIntoConstraints = false
//        spinButton.addTarget(self, action: #selector(spinButtonTapped), for: .touchUpInside)
//        view.addSubview(spinButton)
//        
//        NSLayoutConstraint.activate([
//            spinButton.topAnchor.constraint(equalTo: coinLabel.bottomAnchor, constant: 20),
//            spinButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//            spinButton.widthAnchor.constraint(equalToConstant: 200),
//            spinButton.heightAnchor.constraint(equalToConstant: 50)
//        ])
//    }
//    
//    // MARK: - Set up Slot Machine Reels (4x4 grid)
//    func setupReels() {
//        let reelWidth: CGFloat = 80
//        let reelHeight: CGFloat = 120
//        let reelSpacing: CGFloat = 10
//        let totalWidth = reelWidth * 4 + reelSpacing * 3
//        let totalHeight = reelHeight * 4 + reelSpacing * 3
//        
//        // Set up the center position for the grid
//        let startX = (view.bounds.width - totalWidth) / 2
//        let startY = (view.bounds.height - totalHeight) / 2
//        
//        for row in 0..<4 {
//            for column in 0..<4 {
//                let reel = ReelView(frame: CGRect(
//                    x: startX + CGFloat(column) * (reelWidth + reelSpacing),
//                    y: startY + CGFloat(row) * (reelHeight + reelSpacing),
//                    width: reelWidth,
//                    height: reelHeight
//                ))
//                reels.append(reel)
//                view.addSubview(reel)
//            }
//        }
//    }
//    
//    // MARK: - Spin Button Action
//    @objc func spinButtonTapped() {
//        if totalCoins <= 0 {
//            // No coins, disable the button or show a message
//            return
//        }
//        
//        // Deduct coins
//        totalCoins -= 10
//        coinLabel.text = "Coins: \(totalCoins)"
//        
//        // Spin all the reels
//        for reel in reels {
//            reel.spin()
//        }
//        
//        // Stop the reels after a delay with random symbols
//        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
//            for reel in self.reels {
//                let randomSymbol = GameState.shared.symbols.randomElement()!
//                reel.stopSpinning(with: randomSymbol)
//            }
//        }
//    }
//}
import UIKit

class CustomSlotMachineViewController: UIViewController {
    
    var totalCoins = CoinManager.shared.currentCoins
    var coinLabel: UILabel!
    var spinButton: UIButton!
    var reels: [ReelView] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up the view background
        view.backgroundColor = .lightGray
        
        // Set up total coins label
        setupCoinLabel()
        
        // Set up Slot Machine grid (4x4)
        setupReels()
        
        // Set up Spin button
        setupSpinButton()
    }
    
    // MARK: - Set up Coin Label
    func setupCoinLabel() {
        coinLabel = UILabel()
        coinLabel.text = "Coins: \(CoinManager.shared.currentCoins)"
        coinLabel.font = UIFont.boldSystemFont(ofSize: 24)
        coinLabel.textColor = .black
        coinLabel.textAlignment = .center
        coinLabel.backgroundColor = .white
        coinLabel.layer.cornerRadius = 20
        coinLabel.layer.masksToBounds = true // Ensure the corner radius is applied
        coinLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(coinLabel)
        
        // Set constraints for the coin label to position it on the left side
        NSLayoutConstraint.activate([
            coinLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 70),
            coinLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            coinLabel.widthAnchor.constraint(equalToConstant: 150), // Optional, set width of label
            coinLabel.heightAnchor.constraint(equalToConstant: 50) // Optional, set height of label
        ])
    }
    
    // MARK: - Set up Spin Button
    func setupSpinButton() {
        spinButton = UIButton(type: .system)
        spinButton.setTitle("Spin", for: .normal)
        spinButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
        spinButton.backgroundColor = .blue
        spinButton.setTitleColor(.white, for: .normal)
        spinButton.layer.cornerRadius = 10
        spinButton.translatesAutoresizingMaskIntoConstraints = false
        spinButton.addTarget(self, action: #selector(spinButtonTapped), for: .touchUpInside)
        view.addSubview(spinButton)
        
        NSLayoutConstraint.activate([
            spinButton.topAnchor.constraint(equalTo: reels.last?.bottomAnchor ?? view.topAnchor, constant: 20),
            spinButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinButton.widthAnchor.constraint(equalToConstant: 200),
            spinButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    // MARK: - Set up Slot Machine Reels (4x4 grid)
    func setupReels() {
        let reelWidth: CGFloat = 80
        let reelHeight: CGFloat = 80
        let reelSpacing: CGFloat = 10
        let totalWidth = reelWidth * 4 + reelSpacing * 3
        let totalHeight = reelHeight * 4 + reelSpacing * 3
        
        // Set up the center position for the grid
        let startX = (view.bounds.width - totalWidth) / 2
        let startY = (view.bounds.height - totalHeight) / 2
        
        for row in 0..<4 {
            for column in 0..<4 {
                let reel = ReelView(frame: CGRect(
                    x: startX + CGFloat(column) * (reelWidth + reelSpacing),
                    y: startY + CGFloat(row) * (reelHeight + reelSpacing),
                    width: reelWidth,
                    height: reelHeight
                ))
                reels.append(reel)
                view.addSubview(reel)
            }
        }
    }
    
    // MARK: - Spin Button Action
    @objc func spinButtonTapped() {
        if totalCoins <= 0 {
            // No coins, disable the button or show a message
            return
        }
        
        // Deduct coins
        totalCoins -= 10
        CoinManager.shared.currentCoins = totalCoins
        coinLabel.text = "Coins: \(totalCoins)"
        
        // Spin all the reels
        for reel in reels {
            reel.spin()
        }
        
        // Stop the reels after a delay with random symbols
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            for reel in self.reels {
                let randomSymbol = GameState.shared.symbols.randomElement()!
                reel.stopSpinning(with: randomSymbol)
            }
        }
    }
}
