import UIKit

class ReelView: UIView {
    private var symbolLabel: UILabel!
    private var isSpinning = false
    private var spinningTimer: Timer?
    private var currentSymbolIndex = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupUI()
    }
    
    private func setupUI() {
        backgroundColor = .white
        layer.cornerRadius = 10
        layer.borderWidth = 2
        layer.borderColor = UIColor.lightGray.cgColor
        
        symbolLabel = UILabel()
        symbolLabel.translatesAutoresizingMaskIntoConstraints = false
        symbolLabel.font = .systemFont(ofSize: 40)
        symbolLabel.textAlignment = .center
        addSubview(symbolLabel)
        
        NSLayoutConstraint.activate([
            symbolLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            symbolLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
        
        // Set initial symbol
        symbolLabel.text = GameState.shared.symbols[0].emoji
    }
    
    func spin() {
        guard !isSpinning else { return }
        isSpinning = true
        
        spinningTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            self?.updateSpinningAnimation()
        }
    }
    
    func stopSpinning(with symbol: Symbol) {
        isSpinning = false
        spinningTimer?.invalidate()
        spinningTimer = nil
        
        UIView.animate(withDuration: 0.2) {
            self.symbolLabel.text = symbol.emoji
        }
    }
    
    private func updateSpinningAnimation() {
        currentSymbolIndex = (currentSymbolIndex + 1) % GameState.shared.symbols.count
        symbolLabel.text = GameState.shared.symbols[currentSymbolIndex].emoji
    }
}
