//import UIKit
//
//class SlotMachineViewController: UIViewController {
//    private let gameState = GameState.shared
//    private var reelViews: [ReelView] = []
//    private var balanceLabel: UILabel!
//    private var isSpinning = false
//    
//    private lazy var betControl: BetControlView = {
//        let control = BetControlView()
//        control.translatesAutoresizingMaskIntoConstraints = false
//        control.delegate = self
//        return control
//    }()
//    
//    private lazy var spinButton: UIButton = {
//        let button = UIButton(type: .system)
//        button.translatesAutoresizingMaskIntoConstraints = false
//        button.setTitle("SPIN", for: .normal)
//        button.titleLabel?.font = .systemFont(ofSize: 24, weight: .bold)
//        button.setTitleColor(.white, for: .normal)
//        button.backgroundColor = .systemGreen
//        button.layer.cornerRadius = 25
//        button.addTarget(self, action: #selector(spinButtonTapped), for: .touchUpInside)
//        return button
//    }()
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        checkFirstLaunch()
//        balanceLabel = UILabel()
//        balanceLabel.translatesAutoresizingMaskIntoConstraints = false
//        balanceLabel.textColor = .white
//        balanceLabel.textAlignment = .center
//        balanceLabel.layer.cornerRadius = 20
//        balanceLabel.layer.masksToBounds = true
//        balanceLabel.backgroundColor = UIColor.black.withAlphaComponent(0.3)
//        updateBalanceLabel()
//        
//        setupUI()
//        setupNotifications()
//    }
//    
//    private func setupUI() {
//        // Background gradient
//        let gradientLayer = CAGradientLayer()
//        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
//        gradientLayer.frame = view.bounds
//        view.layer.insertSublayer(gradientLayer, at: 0)
//        
//        // Setup reels container
//        let reelsContainer = UIView()
//        reelsContainer.translatesAutoresizingMaskIntoConstraints = false
//        reelsContainer.backgroundColor = .white
//        reelsContainer.layer.cornerRadius = 20
//        reelsContainer.layer.shadowColor = UIColor.black.cgColor
//        reelsContainer.layer.shadowOffset = CGSize(width: 0, height: 5)
//        reelsContainer.layer.shadowRadius = 10
//        reelsContainer.layer.shadowOpacity = 0.3
//        view.addSubview(reelsContainer)
//        
//        // Setup reels
//        for _ in 0..<3 {
//            let reelView = ReelView()
//            reelView.translatesAutoresizingMaskIntoConstraints = false
//            reelViews.append(reelView)
//            reelsContainer.addSubview(reelView)
//        }
//        
//        // Add other UI elements
//        view.addSubview(balanceLabel)
//        view.addSubview(betControl)
//        view.addSubview(spinButton)
//        
//        // Layout constraints
//        NSLayoutConstraint.activate([
//            balanceLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
//            balanceLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//            balanceLabel.widthAnchor.constraint(equalToConstant: 200),
//            balanceLabel.heightAnchor.constraint(equalToConstant: 40),
//            
//            reelsContainer.centerYAnchor.constraint(equalTo: view.centerYAnchor),
//            reelsContainer.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//            reelsContainer.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.9),
//            reelsContainer.heightAnchor.constraint(equalTo: reelsContainer.widthAnchor, multiplier: 0.6),
//            
//            betControl.topAnchor.constraint(equalTo: reelsContainer.bottomAnchor, constant: 20),
//            betControl.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//            betControl.widthAnchor.constraint(equalTo: reelsContainer.widthAnchor),
//            betControl.heightAnchor.constraint(equalToConstant: 50),
//            
//            spinButton.topAnchor.constraint(equalTo: betControl.bottomAnchor, constant: 20),
//            spinButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//            spinButton.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.6),
//            spinButton.heightAnchor.constraint(equalToConstant: 50)
//        ])
//        
//        // Layout reels
//        for (index, reelView) in reelViews.enumerated() {
//            NSLayoutConstraint.activate([
//                reelView.topAnchor.constraint(equalTo: reelsContainer.topAnchor, constant: 20),
//                reelView.bottomAnchor.constraint(equalTo: reelsContainer.bottomAnchor, constant: -20),
//                reelView.widthAnchor.constraint(equalTo: reelsContainer.widthAnchor, multiplier: 0.25)
//            ])
//            
//            if index == 0 {
//                reelView.leadingAnchor.constraint(equalTo: reelsContainer.leadingAnchor, constant: 20).isActive = true
//            } else if index == reelViews.count - 1 {
//                reelView.trailingAnchor.constraint(equalTo: reelsContainer.trailingAnchor, constant: -20).isActive = true
//            } else {
//                reelView.centerXAnchor.constraint(equalTo: reelsContainer.centerXAnchor).isActive = true
//            }
//        }
//    }
//    
//    private func setupNotifications() {
//        NotificationCenter.default.addObserver(self,
//                                             selector: #selector(balanceDidChange),
//                                             name: .balanceDidChange,
//                                             object: nil)
//    }
//    
//    @objc private func balanceDidChange(_ notification: Notification) {
//        updateBalanceLabel()
//    }
//    
//    private func updateBalanceLabel() {
//        balanceLabel.text = "💰 \(gameState.balance)"
//    }
//    
//    @objc private func spinButtonTapped() {
//        guard !isSpinning && gameState.balance >= gameState.currentBet else { return }
//        
//        isSpinning = true
//        gameState.isSpinning = true
//        gameState.balance -= gameState.currentBet
//        spinButton.isEnabled = false
//        
//        // Spin animation
//        for reelView in reelViews {
//            reelView.spin()
//        }
//        
//        // Stop spinning after delay
//        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
//            self?.stopSpinning()
//        }
//    }
//    
//    private func stopSpinning() {
//        guard isSpinning else { return }
//        
//        isSpinning = false
//        gameState.isSpinning = false
//        spinButton.isEnabled = true
//        
//        // Generate final symbols
//        let finalSymbols = reelViews.map { _ in gameState.symbols.randomElement()! }
//        
//        // Update reels
//        for (index, reelView) in reelViews.enumerated() {
//            reelView.stopSpinning(with: finalSymbols[index])
//        }
//        
//        // Check for win
//        if finalSymbols.allSatisfy({ $0.emoji == finalSymbols[0].emoji }) {
//            let multiplier = finalSymbols[0].value
//            let winAmount = gameState.currentBet * multiplier
//            gameState.balance += winAmount
//            gameState.lastWin = winAmount
//            showWinAlert(amount: winAmount)
//        }
//    }
//    
//    private func showWinAlert(amount: Int) {
//        let alert = UIAlertController(title: "🎉 You Won!",
//                                    message: "You won \(amount) coins!",
//                                    preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "OK", style: .default))
//        present(alert, animated: true)
//    }
//    
//    deinit {
//        NotificationCenter.default.removeObserver(self)
//    }
//    
//    private func checkFirstLaunch() {
//        let userDefaults = UserDefaults.standard
//        let hasLaunchedBefore = userDefaults.bool(forKey: "hasLaunchedBefore")
//
//        if !hasLaunchedBefore {
//            gameState.balance += 1000 // Add 1000 coins on first launch
//            userDefaults.set(true, forKey: "hasLaunchedBefore")
//            userDefaults.synchronize() // Save the change
//        }
//    }
//    
//}
//
//// MARK: - BetControlDelegate
//extension SlotMachineViewController: BetControlDelegate {
//    func didIncreaseBet() {
//        guard gameState.currentBet < gameState.balance else { return }
//        gameState.currentBet += 10
//        betControl.updateBetLabel(with: gameState.currentBet)
//    }
//    
//    func didDecreaseBet() {
//        guard gameState.currentBet > 10 else { return }
//        gameState.currentBet -= 10
//        betControl.updateBetLabel(with: gameState.currentBet)
//    }
//    
//}
import UIKit

class SlotMachineViewController: UIViewController {
    private let gameState = GameState.shared
    private var reelViews: [ReelView] = []
    private var balanceLabel: UILabel!
    private var isSpinning = false
    
    private lazy var betControl: BetControlView = {
        let control = BetControlView()
        control.translatesAutoresizingMaskIntoConstraints = false
        control.delegate = self
        return control
    }()
    
    private lazy var spinButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("SPIN", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 24, weight: .bold)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .systemGreen
        button.layer.cornerRadius = 25
        button.addTarget(self, action: #selector(spinButtonTapped), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkFirstLaunch()
        balanceLabel = UILabel()
        balanceLabel.translatesAutoresizingMaskIntoConstraints = false
        balanceLabel.textColor = .white
        balanceLabel.textAlignment = .center
        balanceLabel.layer.cornerRadius = 20
        balanceLabel.layer.masksToBounds = true
        balanceLabel.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        updateBalanceLabel()
        
        setupUI()
        setupNotifications()
    }
    
    private func setupUI() {
        // Background gradient
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
        
        // Setup reels container (4x3 grid)
        let reelsContainer = UIView()
        reelsContainer.translatesAutoresizingMaskIntoConstraints = false
       // reelsContainer.backgroundColor = .white
        reelsContainer.layer.cornerRadius = 20
        reelsContainer.layer.shadowColor = UIColor.black.cgColor
        reelsContainer.layer.shadowOffset = CGSize(width: 0, height: 5)
        reelsContainer.layer.shadowRadius = 10
        reelsContainer.layer.shadowOpacity = 0.3
        view.addSubview(reelsContainer)
        
        // Setup reels (4 columns x 3 rows)
        for _ in 0..<12 {
            let reelView = ReelView()
            reelView.translatesAutoresizingMaskIntoConstraints = false
            reelViews.append(reelView)
            reelsContainer.addSubview(reelView)
        }
        
        // Add other UI elements
        view.addSubview(balanceLabel)
        view.addSubview(betControl)
        view.addSubview(spinButton)
        
        // Layout constraints
        NSLayoutConstraint.activate([
            balanceLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            balanceLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            balanceLabel.widthAnchor.constraint(equalToConstant: 200),
            balanceLabel.heightAnchor.constraint(equalToConstant: 40),
            
            reelsContainer.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            reelsContainer.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            reelsContainer.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.9),
            reelsContainer.heightAnchor.constraint(equalTo: reelsContainer.widthAnchor, multiplier: 0.75),
            
            betControl.topAnchor.constraint(equalTo: reelsContainer.bottomAnchor, constant: 20),
            betControl.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            betControl.widthAnchor.constraint(equalTo: reelsContainer.widthAnchor),
            betControl.heightAnchor.constraint(equalToConstant: 50),
            
            spinButton.topAnchor.constraint(equalTo: betControl.bottomAnchor, constant: 20),
            spinButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinButton.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.6),
            spinButton.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        // Layout reels (4 columns x 3 rows)
        let rows = 3
        let columns = 4
        for row in 0..<rows {
            for column in 0..<columns {
                let index = row * columns + column
                let reelView = reelViews[index]
                
                NSLayoutConstraint.activate([
                    reelView.widthAnchor.constraint(equalTo: reelsContainer.widthAnchor, multiplier: 1.0 / CGFloat(columns)),
                    reelView.heightAnchor.constraint(equalTo: reelsContainer.heightAnchor, multiplier: 1.0 / CGFloat(rows))
                ])
                
                if row == 0 {
                    reelView.topAnchor.constraint(equalTo: reelsContainer.topAnchor).isActive = true
                } else {
                    reelView.topAnchor.constraint(equalTo: reelViews[(row - 1) * columns + column].bottomAnchor).isActive = true
                }
                
                if column == 0 {
                    reelView.leadingAnchor.constraint(equalTo: reelsContainer.leadingAnchor).isActive = true
                } else {
                    reelView.leadingAnchor.constraint(equalTo: reelViews[row * columns + (column - 1)].trailingAnchor).isActive = true
                }
            }
        }
    }
    
    private func setupNotifications() {
        NotificationCenter.default.addObserver(self,
                                             selector: #selector(balanceDidChange),
                                             name: .balanceDidChange,
                                             object: nil)
    }
    
    @objc private func balanceDidChange(_ notification: Notification) {
        updateBalanceLabel()
    }
    
    private func updateBalanceLabel() {
        balanceLabel.text = "💰 \(gameState.balance)"
    }
    
    @objc private func spinButtonTapped() {
        guard !isSpinning && gameState.balance >= gameState.currentBet else { return }
        
        isSpinning = true
        gameState.isSpinning = true
        gameState.balance -= gameState.currentBet
        spinButton.isEnabled = false
        
        // Spin animation
        for reelView in reelViews {
            reelView.spin()
        }
        
        // Stop spinning after delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            self?.stopSpinning()
        }
    }
    
    private func stopSpinning() {
        guard isSpinning else { return }
        
        isSpinning = false
        gameState.isSpinning = false
        spinButton.isEnabled = true
        
        // Generate final symbols
        let finalSymbols = reelViews.map { _ in gameState.symbols.randomElement()! }
        
        // Update reels
        for (index, reelView) in reelViews.enumerated() {
            reelView.stopSpinning(with: finalSymbols[index])
        }
        
        // Check for win
        if finalSymbols.allSatisfy({ $0.emoji == finalSymbols[0].emoji }) {
            let multiplier = finalSymbols[0].value
            let winAmount = gameState.currentBet * multiplier
            gameState.balance += winAmount
            gameState.lastWin = winAmount
            showWinAlert(amount: winAmount)
        }
    }
    
    private func showWinAlert(amount: Int) {
        let alert = UIAlertController(title: "🎉 You Won!",
                                    message: "You won \(amount) coins!",
                                    preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func checkFirstLaunch() {
        let userDefaults = UserDefaults.standard
        let hasLaunchedBefore = userDefaults.bool(forKey: "hasLaunchedBefore")

        if !hasLaunchedBefore {
            gameState.balance += 1000 // Add 1000 coins on first launch
            userDefaults.set(true, forKey: "hasLaunchedBefore")
            userDefaults.synchronize() // Save the change
        }
    }
}

extension SlotMachineViewController: BetControlDelegate {
    func didIncreaseBet() {
        guard gameState.currentBet < gameState.balance else { return }
        gameState.currentBet += 10
        betControl.updateBetLabel(with: gameState.currentBet)
    }

    func didDecreaseBet() {
        guard gameState.currentBet > 10 else { return }
        gameState.currentBet -= 10
        betControl.updateBetLabel(with: gameState.currentBet)
    }

}
