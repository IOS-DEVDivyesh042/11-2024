import Foundation

class GameState {
    static let shared = GameState()
    
    private var coinManager: CoinManager {
        return CoinManager.shared
    }

    var currentBet: Int = 10
    var lastWin: Int = 0
    var isSpinning: Bool = false
    
    let symbols: [Symbol] = [
        Symbol(emoji: "🍎", value: 2),
        Symbol(emoji: "🍋", value: 3),
        Symbol(emoji: "🍇", value: 4),
        Symbol(emoji: "🍒", value: 5),
        Symbol(emoji: "💎", value: 10)
    ]
    
    var balance: Int {
        get {
            return coinManager.currentCoins
        }
        set {
            coinManager.currentCoins = newValue
            NotificationCenter.default.post(name: .balanceDidChange, object: nil)
        }
    }
    
    private init() {}
}

struct Symbol {
    let emoji: String
    let value: Int
}

extension Notification.Name {
    static let balanceDidChange = Notification.Name("balanceDidChange")
}
