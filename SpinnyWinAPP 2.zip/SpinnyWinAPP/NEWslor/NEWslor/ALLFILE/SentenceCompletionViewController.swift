struct Sentence {
    var text: String
    var options: [String]
    var correctOption: String
    var filledText: String? // New property to store the completed sentence
}

import UIKit

class SentenceCompletionViewController: UIViewController {
    private var sentences: [Sentence] = [
          Sentence(text: "The sun is _______ in the sky.", options: ["bright", "cloudy", "dim", "setting"], correctOption: "bright"),
          Sentence(text: "She _______ the report before the deadline.", options: ["completed", "submitted", "reviewed", "started"], correctOption: "submitted"),
          Sentence(text: "He _______ to the park every morning.", options: ["walks", "ran", "jumps", "sleeps"], correctOption: "walks"),
          Sentence(text: "The cake tastes _______.", options: ["delicious", "salty", "bitter", "bland"], correctOption: "delicious"),
          Sentence(text: "They _______ the project last week.", options: ["finished", "start", "delay", "paused"], correctOption: "finished"),
          Sentence(text: "The flowers are _______ in spring.", options: ["blooming", "falling", "drying", "wilting"], correctOption: "blooming"),
          Sentence(text: "She _______ her best friend daily.", options: ["calls", "writes", "visits", "avoids"], correctOption: "calls"),
          Sentence(text: "The car is _______ faster than usual.", options: ["moving", "driving", "running", "slowing"], correctOption: "moving"),
          Sentence(text: "He _______ a new book recently.", options: ["read", "writes", "reads", "watch"], correctOption: "read"),
          Sentence(text: "The baby is _______ soundly.", options: ["sleeping", "crying", "playing", "smiling"], correctOption: "sleeping"),
          Sentence(text: "The pizza was _______ hot.", options: ["very", "not", "barely", "cold"], correctOption: "very"),
          Sentence(text: "They _______ the exam with ease.", options: ["passed", "failed", "ignored", "forgot"], correctOption: "passed"),
          Sentence(text: "The house is _______ painted.", options: ["newly", "faded", "rarely", "badly"], correctOption: "newly"),
          Sentence(text: "She _______ the keys on the table.", options: ["placed", "lost", "took", "broke"], correctOption: "placed"),
          Sentence(text: "The students _______ for the trip tomorrow.", options: ["prepare", "prepared", "preparing", "planned"], correctOption: "prepare"),
          Sentence(text: "The movie was _______ to watch.", options: ["exciting", "boring", "confusing", "old"], correctOption: "exciting"),
          Sentence(text: "The storm _______ trees and power lines.", options: ["damaged", "built", "created", "repaired"], correctOption: "damaged"),
          Sentence(text: "The painting looks _______ on the wall.", options: ["beautiful", "broken", "empty", "new"], correctOption: "beautiful"),
          Sentence(text: "The athlete _______ a world record.", options: ["broke", "made", "forgot", "kept"], correctOption: "broke"),
          Sentence(text: "She _______ a gift for her mother.", options: ["bought", "found", "gave", "received"], correctOption: "bought"),
          Sentence(text: "The dog _______ in the backyard.", options: ["plays", "slept", "eats", "sings"], correctOption: "plays"),
          Sentence(text: "The train _______ at the station on time.", options: ["arrived", "departed", "delayed", "stopped"], correctOption: "arrived"),
          Sentence(text: "He _______ the email to the wrong person.", options: ["sent", "deleted", "replied", "ignored"], correctOption: "sent")
      ]

    private var currentSentenceIndex = 0
    private let sentenceLabel = UILabel()
    private let optionsStackView = UIStackView()
    private let doneButton = UIButton(type: .system)
    private let coinView = UIView()
    private let coinLabel = UILabel()
    private var score = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        showSentence()
    }

    private func setupUI() {
        view.backgroundColor = .white

        // Sentence Label
        sentenceLabel.font = .systemFont(ofSize: 24, weight: .bold)
        sentenceLabel.numberOfLines = 0
        sentenceLabel.textAlignment = .center
        sentenceLabel.textColor = .white
        sentenceLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sentenceLabel)

        // Options StackView
        optionsStackView.axis = .vertical
        optionsStackView.spacing = 12
        optionsStackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(optionsStackView)

        // Coin View
        coinView.backgroundColor = .systemGray6
        coinView.layer.cornerRadius = 20
        coinView.layer.masksToBounds = true
        coinView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(coinView)

        // Coin Label
        coinLabel.font = .systemFont(ofSize: 18, weight: .semibold)
        coinLabel.textColor = .black
        coinLabel.text = "Coins: \(CoinManager.shared.currentCoins)"
        coinLabel.translatesAutoresizingMaskIntoConstraints = false
        coinView.addSubview(coinLabel)

        // Coin Image
        let coinImageView = UIImageView(image: UIImage(systemName: "dollarsign.circle.fill"))
        coinImageView.tintColor = .systemYellow
        coinImageView.translatesAutoresizingMaskIntoConstraints = false
        coinView.addSubview(coinImageView)

        // Done Button
        doneButton.setTitle("Done", for: .normal)
        doneButton.titleLabel?.font = .systemFont(ofSize: 20, weight: .semibold)
        doneButton.addTarget(self, action: #selector(doneButtonTapped), for: .touchUpInside)
        doneButton.translatesAutoresizingMaskIntoConstraints = false
        doneButton.isHidden = true
        view.addSubview(doneButton)

        // Constraints
        NSLayoutConstraint.activate([
            sentenceLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
            sentenceLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            sentenceLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            optionsStackView.topAnchor.constraint(equalTo: sentenceLabel.bottomAnchor, constant: 30),
            optionsStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            optionsStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            coinView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            coinView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            coinView.widthAnchor.constraint(equalToConstant: 200),
            coinView.heightAnchor.constraint(equalToConstant: 50),

            coinImageView.centerYAnchor.constraint(equalTo: coinView.centerYAnchor),
            coinImageView.leadingAnchor.constraint(equalTo: coinView.leadingAnchor, constant: 8),
            coinImageView.widthAnchor.constraint(equalToConstant: 30),
            coinImageView.heightAnchor.constraint(equalToConstant: 30),

            coinLabel.centerYAnchor.constraint(equalTo: coinView.centerYAnchor),
            coinLabel.leadingAnchor.constraint(equalTo: coinImageView.trailingAnchor, constant: 8),
            coinLabel.trailingAnchor.constraint(equalTo: coinView.trailingAnchor, constant: -8),

            doneButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            doneButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }

    private func showSentence() {
        guard currentSentenceIndex < sentences.count else {
            displayScore()
            return
        }

        // Clear previous options
        optionsStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }

        // Get the current sentence
        var currentSentence = sentences[currentSentenceIndex]
        
        // If a filledText is set, use that, otherwise use the original sentence text
        sentenceLabel.text = currentSentence.filledText ?? currentSentence.text

        // Add options as buttons
        for option in currentSentence.options {
            let button = UIButton(type: .system)
            button.setTitle(option, for: .normal)
            button.titleLabel?.font = .systemFont(ofSize: 18)
            button.backgroundColor = .systemGray6
            button.layer.cornerRadius = 8
            button.tintColor = .black
            button.contentEdgeInsets = UIEdgeInsets(top: 12, left: 16, bottom: 12, right: 16)
            button.addTarget(self, action: #selector(optionButtonTapped(_:)), for: .touchUpInside)
            optionsStackView.addArrangedSubview(button)
        }
    }

    @objc private func optionButtonTapped(_ sender: UIButton) {
           guard let selectedOption = sender.title(for: .normal) else { return }
   
           // Ensure the current index is within bounds
           guard currentSentenceIndex < sentences.count else { return }
   
           // Update sentence text with the selected option
           var currentSentence = sentences[currentSentenceIndex]
           currentSentence.text = currentSentence.text.replacingOccurrences(of: "_______", with: selectedOption)
           sentences[currentSentenceIndex] = currentSentence
   
           // Check correctness
           if selectedOption == currentSentence.correctOption {
               score += 1
           }
   
           // Show updated sentence
           sentenceLabel.text = currentSentence.text
   
           // Move to the next sentence after a delay
           DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
               self.currentSentenceIndex += 1
   
               // Check if there are more sentences to show
               if self.currentSentenceIndex < self.sentences.count {
                   self.showSentence()
               } else {
                   // End of quiz, display the score
                   self.displayScore()
               }
           }
       }


    @objc private func doneButtonTapped() {
        displayScore()
    }

    private func displayScore() {
        let alertController = UIAlertController(title: "Quiz Complete!",
                                                message: "Your score: \(score) / \(sentences.count)",
                                                preferredStyle: .alert)

        let restartAction = UIAlertAction(title: "Restart", style: .default) { _ in
            self.restartQuiz()
        }
        alertController.addAction(restartAction)

        present(alertController, animated: true)
    }

    private func restartQuiz() {
        currentSentenceIndex = 0
        score = 0
        showSentence()
    }
}
