//
//  InductanceVC.swift
//  EquivaSync
//
//  Created by Shubham Parekh on 09/11/24.
//

import UIKit

class InductanceVC: UIViewController {

    @IBOutlet weak var v1: UIView!
    @IBOutlet weak var v2: UIView!
    @IBOutlet weak var v3: UIView!
    
    @IBOutlet weak var txtinput: UITextField!
    
    @IBOutlet weak var btn1: UIButton!  // Button for Millihenries
    @IBOutlet weak var btn2: UIButton!  // Button for Henries
    
    @IBOutlet weak var lblour: UILabel! // Label to display the output
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set corner radius for views
        v1.layer.cornerRadius = 40
        v2.layer.cornerRadius = 40
        v3.layer.cornerRadius = 40
        
        // Set corner radius for buttons
        btn1.layer.cornerRadius = 10
        btn2.layer.cornerRadius = 10
        
        // Set initial button titles
        btn1.setTitle("mH", for: .normal)
        btn2.setTitle("H", for: .normal)
        
        // Set target actions for each button
        btn1.addTarget(self, action: #selector(showOutputInMillihenries), for: .touchUpInside)
        btn2.addTarget(self, action: #selector(showOutputInHenries), for: .touchUpInside)
    }
    
    @objc func showOutputInMillihenries() {
        guard let inputText = txtinput.text, let inputValue = Double(inputText) else {
            lblour.text = "Invalid input. Enter a number."
            return
        }
        
        // Conversion to Millihenries (assuming input in Henries)
        let outputValue = inputValue * 1000  // Henries to Millihenries
        
        // Display the result on the output label
        lblour.text = "\(outputValue) mH"
    }
    
    @objc func showOutputInHenries() {
        guard let inputText = txtinput.text, let inputValue = Double(inputText) else {
            lblour.text = "Invalid input. Enter a number."
            return
        }
        
        // Conversion to Henries (assuming input in Millihenries)
        let outputValue = inputValue / 1000  // Millihenries to Henries
        
        // Display the result on the output label
        lblour.text = "\(outputValue) H"
    }
}
