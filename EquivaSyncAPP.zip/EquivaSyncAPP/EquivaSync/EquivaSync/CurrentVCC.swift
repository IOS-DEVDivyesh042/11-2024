//
//  CurrentVC.swift
//  EquivaSync
//
//  Created by Shubham Parekh on 09/11/24.
//

import UIKit

class CurrentVCC: UIViewController {

    @IBOutlet weak var v1: UIView!
    @IBOutlet weak var v2: UIView!
    @IBOutlet weak var v3: UIView!
    
    @IBOutlet weak var txtinput: UITextField!
    
    @IBOutlet weak var btn1: UIButton!  // Button for Milliamperes
    @IBOutlet weak var btn2: UIButton!  // Button for Amperes
    
    @IBOutlet weak var lblour: UILabel! // Label to display the output
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set corner radius for views
        v1.layer.cornerRadius = 40
        v2.layer.cornerRadius = 40
        v3.layer.cornerRadius = 40
        
        // Set corner radius for buttons
        btn1.layer.cornerRadius = 10
        btn2.layer.cornerRadius = 10
        
        // Set initial button titles
        btn1.setTitle("mA", for: .normal)
        btn2.setTitle("A", for: .normal)
        
        // Set target actions for each button
        btn1.addTarget(self, action: #selector(showOutputInMilliamperes), for: .touchUpInside)
        btn2.addTarget(self, action: #selector(showOutputInAmperes), for: .touchUpInside)
    }
    
    @objc func showOutputInMilliamperes() {
        guard let inputText = txtinput.text, let inputValue = Double(inputText) else {
            lblour.text = "Invalid input. Enter a number."
            return
        }
        
        // Conversion to Milliamperes (assuming input in Amperes)
        let outputValue = inputValue * 1000  // Amperes to Milliamperes
        
        // Display the result on the output label
        lblour.text = "\(outputValue) mA"
    }
    
    @objc func showOutputInAmperes() {
        guard let inputText = txtinput.text, let inputValue = Double(inputText) else {
            lblour.text = "Invalid input. Enter a number."
            return
        }
        
        // Conversion to Amperes (assuming input in Milliamperes)
        let outputValue = inputValue / 1000  // Milliamperes to Amperes
        
        // Display the result on the output label
        lblour.text = "\(outputValue) A"
    }
}
