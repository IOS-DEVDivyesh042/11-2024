//
//  FlowVC.swift
//  EquivaSync
//
//  Created by Shubham Parekh on 09/11/24.
//

import UIKit

class FlowVCC: UIViewController {

    @IBOutlet weak var v1: UIView!
    @IBOutlet weak var v2: UIView!
    @IBOutlet weak var v3: UIView!
    
    @IBOutlet weak var txtinput: UITextField!
    
    @IBOutlet weak var btn1: UIButton!  // Button for Liters per second
    @IBOutlet weak var btn2: UIButton!  // Button for Cubic meters per second
    
    @IBOutlet weak var lblour: UILabel! // Label to display the output
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set corner radius for views
        v1.layer.cornerRadius = 40
        v2.layer.cornerRadius = 40
        v3.layer.cornerRadius = 40
        
        // Set corner radius for buttons
        btn1.layer.cornerRadius = 10
        btn2.layer.cornerRadius = 10
        
        // Set initial button titles
        btn1.setTitle("L/s", for: .normal)
        btn2.setTitle("m³/s", for: .normal)
        
        // Set target actions for each button
        btn1.addTarget(self, action: #selector(showOutputInLitersPerSecond), for: .touchUpInside)
        btn2.addTarget(self, action: #selector(showOutputInCubicMetersPerSecond), for: .touchUpInside)
    }
    
    @objc func showOutputInLitersPerSecond() {
        guard let inputText = txtinput.text, let inputValue = Double(inputText) else {
            lblour.text = "Invalid input. Enter a number."
            return
        }
        
        // Conversion to Liters per second (assuming input in cubic meters per second)
        let outputValue = inputValue * 1000  // Cubic meters per second to liters per second
        
        // Display the result on the output label
        lblour.text = "\(outputValue) L/s"
    }
    
    @objc func showOutputInCubicMetersPerSecond() {
        guard let inputText = txtinput.text, let inputValue = Double(inputText) else {
            lblour.text = "Invalid input. Enter a number."
            return
        }
        
        // Conversion to Cubic meters per second (assuming input in liters per second)
        let outputValue = inputValue / 1000  // Liters per second to cubic meters per second
        
        // Display the result on the output label
        lblour.text = "\(outputValue) m³/s"
    }
}
