//
//  FluxVC.swift
//  EquivaSync
//
//  Created by Shubham Parekh on 09/11/24.
//

import UIKit

class FluxVC: UIViewController {

    @IBOutlet weak var v1: UIView!
    @IBOutlet weak var v2: UIView!
    @IBOutlet weak var v3: UIView!
    
    @IBOutlet weak var txtinput: UITextField!
    
    @IBOutlet weak var btn1: UIButton!  // Button for Milliwebers
    @IBOutlet weak var btn2: UIButton!  // Button for Webers
    
    @IBOutlet weak var lblour: UILabel! // Label to display the output
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
       
        // Set corner radius for views
        v1.layer.cornerRadius = 40
        v2.layer.cornerRadius = 40
        v3.layer.cornerRadius = 40
        
        // Set corner radius for buttons
        btn1.layer.cornerRadius = 10
        btn2.layer.cornerRadius = 10
        
        // Set initial button titles
        btn1.setTitle("mWb", for: .normal)
        btn2.setTitle("Wb", for: .normal)
        
        // Set target actions for each button
        btn1.addTarget(self, action: #selector(showOutputInMilliwebers), for: .touchUpInside)
        btn2.addTarget(self, action: #selector(showOutputInWebers), for: .touchUpInside)
    }
    
    @objc func showOutputInMilliwebers() {
        guard let inputText = txtinput.text, let inputValue = Double(inputText) else {
            lblour.text = "Invalid input. Enter a number."
            return
        }
        
        // Conversion to Milliwebers (assuming input in Webers)
        let outputValue = inputValue * 1000  // Webers to Milliwebers
        
        // Display the result on the output label
        lblour.text = "\(outputValue) mWb"
    }
    
    @objc func showOutputInWebers() {
        guard let inputText = txtinput.text, let inputValue = Double(inputText) else {
            lblour.text = "Invalid input. Enter a number."
            return
        }
        
        // Conversion to Webers (assuming input in Milliwebers)
        let outputValue = inputValue / 1000  // Milliwebers to Webers
        
        // Display the result on the output label
        lblour.text = "\(outputValue) Wb"
    }
}
