//
//  ViewController.swift
//  EquivaSync
//
//  Created by Shubham Parekh on 09/11/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var view1: UIView!
    

    @IBOutlet weak var view2: UIView!
    
    
    @IBOutlet weak var view3: UIView!
    
    @IBOutlet weak var btn11: UIButton!
    
    
    @IBOutlet weak var btn22: UIButton!
    
    @IBOutlet weak var btn33: UIButton!
    
    
    @IBOutlet weak var btn44: UIButton!
    
    @IBOutlet weak var btn55: UIButton!
    
    @IBOutlet weak var btn66: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        view1.layer.cornerRadius = 40
        view2.layer.cornerRadius = 40
        view3.layer.cornerRadius = 40
        
        
        btn11.layer.cornerRadius = 12
        btn22.layer.cornerRadius = 12
        btn33.layer.cornerRadius = 12
        btn44.layer.cornerRadius = 12
        btn55.layer.cornerRadius = 12
        btn66.layer.cornerRadius = 12
        
        
        
        // Do any additional setup after loading the view.
    }


}

