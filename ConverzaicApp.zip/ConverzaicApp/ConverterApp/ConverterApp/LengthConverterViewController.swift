import UIKit

class LengthConverterViewController: UIViewController {
    // Views for Top Section
    let topContainerView: UIView = {
        let view = UIView()
        view.layer.insertSublayer(gradientLayer(colors: [UIColor.red, UIColor.orange]), at: 0)
        return view
    }()
    
    let inputTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter length"
        textField.borderStyle = .none
        textField.textAlignment = .center
        textField.font = UIFont.boldSystemFont(ofSize: 22)
        textField.textColor = .black
        textField.backgroundColor = UIColor.white.withAlphaComponent(0.8)
        textField.layer.cornerRadius = 10
        return textField
    }()
    
    let outputLabel1 = createOutputLabel(withText: "Meters: 0")
    let outputLabel2 = createOutputLabel(withText: "Centimeters: 0")
    let outputLabel3 = createOutputLabel(withText: "Inches: 0")
    
    // Views for Bottom Section
    let buttonContainerView: UIView = {
        let view = UIView()
        view.layer.insertSublayer(gradientLayer(colors: [UIColor.yellow, UIColor.orange]), at: 0)
        return view
    }()
    
    var numberButtons = [UIButton]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // view.backgroundColor = .white
        setupViews()
        setupButtons()
    }
    
    static func createOutputLabel(withText text: String) -> UILabel {
        let label = UILabel()
        label.text = text
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        label.textColor = .white
        label.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        label.layer.cornerRadius = 8
        label.layer.masksToBounds = true
        return label
    }
    
    func setupViews() {
        view.addSubview(topContainerView)
        topContainerView.addSubview(inputTextField)
        topContainerView.addSubview(outputLabel1)
        topContainerView.addSubview(outputLabel2)
        topContainerView.addSubview(outputLabel3)
        view.addSubview(buttonContainerView)
        
        // Enable Auto Layout
        topContainerView.translatesAutoresizingMaskIntoConstraints = false
        inputTextField.translatesAutoresizingMaskIntoConstraints = false
        outputLabel1.translatesAutoresizingMaskIntoConstraints = false
        outputLabel2.translatesAutoresizingMaskIntoConstraints = false
        outputLabel3.translatesAutoresizingMaskIntoConstraints = false
        buttonContainerView.translatesAutoresizingMaskIntoConstraints = false
        
        // Constraints for topContainerView and buttonContainerView
        NSLayoutConstraint.activate([
            topContainerView.topAnchor.constraint(equalTo: view.topAnchor),
            topContainerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topContainerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topContainerView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5),
            
            buttonContainerView.bottomAnchor.constraint(equalTo: view.bottomAnchor,constant: -15),
            buttonContainerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            buttonContainerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            buttonContainerView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5)
        ])
        
        // Constraints for inputTextField
        NSLayoutConstraint.activate([
            inputTextField.topAnchor.constraint(equalTo: topContainerView.safeAreaLayoutGuide.topAnchor, constant: 20),
            inputTextField.centerXAnchor.constraint(equalTo: topContainerView.centerXAnchor),
            inputTextField.widthAnchor.constraint(equalTo: topContainerView.widthAnchor, multiplier: 0.8),
            inputTextField.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        // Constraints for output labels
        NSLayoutConstraint.activate([
            outputLabel1.topAnchor.constraint(equalTo: inputTextField.bottomAnchor, constant: 20),
            outputLabel1.leadingAnchor.constraint(equalTo: topContainerView.leadingAnchor, constant: 20),
            outputLabel1.trailingAnchor.constraint(equalTo: topContainerView.trailingAnchor, constant: -20),
            
            outputLabel2.topAnchor.constraint(equalTo: outputLabel1.bottomAnchor, constant: 10),
            outputLabel2.leadingAnchor.constraint(equalTo: topContainerView.leadingAnchor, constant: 20),
            outputLabel2.trailingAnchor.constraint(equalTo: topContainerView.trailingAnchor, constant: -20),
            
            outputLabel3.topAnchor.constraint(equalTo: outputLabel2.bottomAnchor, constant: 10),
            outputLabel3.leadingAnchor.constraint(equalTo: topContainerView.leadingAnchor, constant: 20),
            outputLabel3.trailingAnchor.constraint(equalTo: topContainerView.trailingAnchor, constant: -20),
        ])
    }
    
    func setupButtons() {
        let buttonTitles = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "⌫", "C"]
        
        let verticalStackView = UIStackView()
        verticalStackView.axis = .vertical
        verticalStackView.alignment = .center
        verticalStackView.distribution = .equalSpacing
        verticalStackView.spacing = 10 // Spacing between rows
        buttonContainerView.addSubview(verticalStackView)
        
        verticalStackView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            verticalStackView.centerXAnchor.constraint(equalTo: buttonContainerView.centerXAnchor),
            verticalStackView.centerYAnchor.constraint(equalTo: buttonContainerView.centerYAnchor)
        ])
        
        // Add buttons to the stack view with 10 points spacing
        for row in 0..<4 {
            let horizontalStackView = UIStackView()
            horizontalStackView.axis = .horizontal
            horizontalStackView.alignment = .center
            horizontalStackView.distribution = .equalSpacing
            horizontalStackView.spacing = 10 // Spacing between buttons in a row
            verticalStackView.addArrangedSubview(horizontalStackView)
            
            for column in 0..<3 {
                let index = row * 3 + column
                guard index < buttonTitles.count else { break }
                
                let button = createCircleButton(title: buttonTitles[index])
                horizontalStackView.addArrangedSubview(button)
                
                button.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    button.widthAnchor.constraint(equalToConstant: 80),
                    button.heightAnchor.constraint(equalToConstant: 80)
                ])
                
                numberButtons.append(button)
            }
        }
    }

    
    func createCircleButton(title: String) -> UIButton {
        let button = UIButton(type: .custom)
        button.layer.cornerRadius = 40
        button.layer.masksToBounds = true
        button.backgroundColor = UIColor.systemBlue.withAlphaComponent(0.8)
        
        // Add the inner square inset
        let insetLayer = CALayer()
        insetLayer.frame = CGRect(x: 20, y: 20, width: 40, height: 40)
        insetLayer.backgroundColor = UIColor.white.cgColor
        insetLayer.cornerRadius = 5
        button.layer.addSublayer(insetLayer)
        
        // Set title and style
        button.setTitle(title, for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        button.addTarget(self, action: #selector(buttonTapped(_:)), for: .touchUpInside)
        
        return button
    }
    
    @objc func buttonTapped(_ sender: UIButton) {
        let buttonText = sender.titleLabel?.text ?? ""
        
        switch buttonText {
        case "C":
            inputTextField.text = ""
            clearOutputLabels()
        case "⌫":
            inputTextField.text = String(inputTextField.text?.dropLast() ?? "")
            if inputTextField.text?.isEmpty == true {
                clearOutputLabels() // Clear output if text field is empty
            } else {
                convertLength() // Update the output if there's still text left
            }
        default:
            inputTextField.text?.append(buttonText)
            convertLength()
        }
    }
    
    func convertLength() {
        guard let inputText = inputTextField.text, let inputValue = Double(inputText) else {
            clearOutputLabels()
            return
        }
        
        let meters = inputValue
        let centimeters = meters * 100
        let inches = meters * 39.3701
        
        outputLabel1.text = "Meters: \(meters)"
        outputLabel2.text = "Centimeters: \(centimeters)"
        outputLabel3.text = "Inches: \(inches)"
    }
    
    func clearOutputLabels() {
        outputLabel1.text = "Meters: 0"
        outputLabel2.text = "Centimeters: 0"
        outputLabel3.text = "Inches: 0"
    }
    
    static func gradientLayer(colors: [UIColor]) -> CAGradientLayer {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = colors.map { $0.cgColor }
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 1.0)
        return gradientLayer
    }
}
