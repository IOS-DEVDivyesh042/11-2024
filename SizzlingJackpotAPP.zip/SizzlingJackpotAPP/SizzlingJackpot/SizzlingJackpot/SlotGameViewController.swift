import UIKit

class SlotGameViewController: UIViewController {
    
    private var slotImageViews: [[UIImageView]] = []
    private let spinButton = UIButton(type: .system)
    private let coinLabel = UILabel()
    private let images = [
        UIImage(named: "pirate1"),
        UIImage(named: "pirate2"),
        UIImage(named: "pirate3"),
        UIImage(named: "pirate4"),
        UIImage(named: "pirate5")
    ]
    
    private var coins: Int {
        get {
            return UserDefaults.standard.integer(forKey: "coins")
        }
        set {
            UserDefaults.standard.set(newValue, forKey: "coins")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        coins = max(coins, 1000) // Initialize coins to 1000 if not set
        setupUI()
        updateCoinLabel()
    }
    
    private func setupUI() {
        // Setup Coin Label
        coinLabel.font = UIFont.boldSystemFont(ofSize: 24)
        coinLabel.textAlignment = .center
        coinLabel.textColor = .white
        coinLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(coinLabel)
        
        // Setup Slot Image Views with Blue Background
        for _ in 0..<3 {
            var row: [UIImageView] = []
            for _ in 0..<3 {
                let imageView = UIImageView()
                imageView.contentMode = .scaleAspectFit
                imageView.backgroundColor = .systemBlue
                imageView.layer.borderWidth = 1
                imageView.layer.borderColor = UIColor.black.cgColor
                imageView.translatesAutoresizingMaskIntoConstraints = false
                row.append(imageView)
                view.addSubview(imageView)
            }
            slotImageViews.append(row)
        }
        
        // Setup Spin Button
        spinButton.setTitle("Spin", for: .normal)
        spinButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
        spinButton.backgroundColor = .systemOrange // Set background color to system orange
        spinButton.setTitleColor(.white, for: .normal) // Set title color to white
        spinButton.layer.cornerRadius = 10 // Rounded corners
        spinButton.addTarget(self, action: #selector(spinButtonTapped), for: .touchUpInside)
        spinButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(spinButton)
        
        // Layout Constraints
        setupConstraints()
    }
    
    private func setupConstraints() {
        // Coin Label Constraints
        NSLayoutConstraint.activate([
            coinLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            coinLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        
        // Slot Grid Constraints
        for (rowIndex, row) in slotImageViews.enumerated() {
            for (columnIndex, imageView) in row.enumerated() {
                NSLayoutConstraint.activate([
                    imageView.widthAnchor.constraint(equalToConstant: 80),
                    imageView.heightAnchor.constraint(equalToConstant: 80),
                    imageView.topAnchor.constraint(equalTo: coinLabel.bottomAnchor, constant: CGFloat(20 + rowIndex * 90)),
                    imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: CGFloat((columnIndex - 1) * 90)) // Centered position
                ])
            }
        }
        
        // Spin Button Constraints
        NSLayoutConstraint.activate([
            spinButton.topAnchor.constraint(equalTo: slotImageViews[2][2].bottomAnchor, constant: 20),
            spinButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinButton.widthAnchor.constraint(equalToConstant: 100),
            spinButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc private func spinButtonTapped() {
        guard coins >= 100 else {
            showResultPopup(message: "Not enough coins to spin!")
            return
        }
        spinReels()
    }
    
    private func spinReels() {
        UIView.animate(withDuration: 0.2, animations: {
            for row in self.slotImageViews {
                for imageView in row {
                    imageView.image = self.images.randomElement() ?? self.images[0]
                    imageView.alpha = 0.5
                }
            }
        }) { _ in
            UIView.animate(withDuration: 0.2) {
                for row in self.slotImageViews {
                    for imageView in row {
                        imageView.alpha = 1.0
                    }
                }
            }
            self.checkForWin()
        }
    }
    
    private func checkForWin() {
        var isWin = false
        for row in slotImageViews {
            let firstImage = row[0].image
            if row.allSatisfy({ $0.image == firstImage }) {
                isWin = true
                break
            }
        }
        
        if isWin {
            coins += 1000
            showResultPopup(message: "Congratulations! You won +1000 coins!")
        } else {
            coins -= 100
            showResultPopup(message: "You lost! -100 coins!")
        }
        updateCoinLabel()
    }
    
    private func updateCoinLabel() {
        coinLabel.text = "Coins: \(coins)"
    }
    
    private func showResultPopup(message: String) {
        let alertController = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        present(alertController, animated: true) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                alertController.dismiss(animated: true, completion: nil)
            }
        }
    }
}
