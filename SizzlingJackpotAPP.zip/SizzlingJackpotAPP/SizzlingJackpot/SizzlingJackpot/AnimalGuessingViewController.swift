import UIKit

class AnimalGuessingViewController: UIViewController {
    
    // List of animals
    private let animals = ["LION", "TIGER", "ELEPHANT", "GIRAFFE", "ZEBRA", "KANGAROO", "PANDA", "HIPPOPOTAMUS", "CROCODILE", "RABBIT"]
    private var currentAnimal: String = ""
    
    private let coinsKey = "coins"
    private var roundsPlayed = 0
    private let maxRounds = 5 // Set the number of rounds for the game
    
    private let wordLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 32, weight: .heavy)
        label.textAlignment = .center
        label.textColor = .black
        return label
    }()
    
    private let coinsLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 24, weight: .heavy)
        label.textAlignment = .center
        label.textColor = .white
        return label
    }()
    
    private let instructionLabel: UILabel = {
        let label = UILabel()
        label.text = "Guess the animal name and write inside the box"
        label.numberOfLines = 0
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 20, weight: .heavy)
        label.textAlignment = .center
        return label
    }()
    
    private let guessTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter animal name"
        textField.borderStyle = .roundedRect
        textField.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        textField.layer.borderColor = UIColor.systemBlue.cgColor
        textField.layer.borderWidth = 2
        textField.layer.cornerRadius = 10
        textField.layer.shadowColor = UIColor.black.cgColor
        textField.layer.shadowOpacity = 0.2
        textField.layer.shadowOffset = CGSize(width: 0, height: 2)
        textField.layer.shadowRadius = 5
        return textField
    }()
    
    private let submitButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Submit", for: .normal)
        button.backgroundColor = UIColor.systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.2
        button.layer.shadowOffset = CGSize(width: 0, height: 2)
        button.layer.shadowRadius = 5
        return button
    }()
    
    private let resultLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 24, weight: .medium)
        label.textAlignment = .center
        return label
    }()
    
    private var coins: Int = 1000 {
        didSet {
            UserDefaults.standard.set(coins, forKey: coinsKey)
            coinsLabel.text = "Coins: \(coins)"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        loadCoins()
        newGame()
        
        // Adding a tap gesture to dismiss the keyboard
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
        
        // Adding a "Done" button to the keyboard
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(dismissKeyboard))
        toolbar.items = [doneButton]
        guessTextField.inputAccessoryView = toolbar
    }
    
    private func setupUI() {
        // Setup coins label
        coinsLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(coinsLabel)
        
        // Setup instruction label
        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(instructionLabel)
        
        // Setup word label
        wordLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(wordLabel)
        
        // Setup guess text field
        guessTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(guessTextField)
        
        // Setup submit button
        submitButton.translatesAutoresizingMaskIntoConstraints = false
        submitButton.addTarget(self, action: #selector(checkGuess), for: .touchUpInside)
        view.addSubview(submitButton)
        
        // Setup result label
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(resultLabel)
        
        // Layout constraints
        NSLayoutConstraint.activate([
            coinsLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            coinsLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            instructionLabel.topAnchor.constraint(equalTo: coinsLabel.bottomAnchor, constant: 20),
            instructionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            instructionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            wordLabel.topAnchor.constraint(equalTo: instructionLabel.bottomAnchor, constant: 30),
            wordLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            guessTextField.topAnchor.constraint(equalTo: wordLabel.bottomAnchor, constant: 30),
            guessTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            guessTextField.widthAnchor.constraint(equalToConstant: 250),
            guessTextField.heightAnchor.constraint(equalToConstant: 80),
            
            submitButton.topAnchor.constraint(equalTo: guessTextField.bottomAnchor, constant: 20),
            submitButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            submitButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            submitButton.heightAnchor.constraint(equalToConstant: 50),
            
            resultLabel.topAnchor.constraint(equalTo: submitButton.bottomAnchor, constant: 30),
            resultLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
    }
    
    private func loadCoins() {
        coins = UserDefaults.standard.integer(forKey: coinsKey)
    }
    
    private func newGame() {
        if coins < 100 {
            showPopup(message: "You need at least 100 coins to play!")
            return
        }
        
        currentAnimal = animals.randomElement() ?? ""
        resultLabel.text = ""
        guessTextField.text = ""
        wordLabel.text = scramble(word: currentAnimal)
        roundsPlayed = 0 // Reset rounds for the new game
    }
    
    private func scramble(word: String) -> String {
        return String(word.shuffled())
    }
    
    @objc private func checkGuess() {
        guard let guess = guessTextField.text?.uppercased() else { return }
        
        if guess == currentAnimal {
            coins += 1000
            roundsPlayed += 1
            showPopup(message: "Correct! You earned 1000 coins! Total coins: \(coins)")
        } else {
            coins -= 100
            showPopup(message: "Wrong! You lost 100 coins. Total coins: \(coins)")
        }
        
        if roundsPlayed >= maxRounds {
            showRestartPopup()
        } else {
            newGame() // Start a new game round
        }
    }
    
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
    
    private func showPopup(message: String) {
        let popup = CustomPopupView(frame: CGRect(x: 0, y: 0, width: 250, height: 150))
        popup.center = view.center
        popup.messageLabel.text = message
        view.addSubview(popup)
        
        // Dismiss the popup after 2 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            popup.removeFromSuperview()
        }
    }
    
    private func showRestartPopup() {
        let popup = CustomPopupView(frame: CGRect(x: 0, y: 0, width: 250, height: 200))
        popup.center = view.center
        popup.messageLabel.text = "Game Over! You played \(maxRounds) rounds.\nRestart the game?"
        
        let restartButton = UIButton(type: .system)
        restartButton.setTitle("Restart", for: .normal)
        restartButton.frame = CGRect(x: 20, y: 80, width: 210, height: 40)
        restartButton.addTarget(self, action: #selector(restartGame), for: .touchUpInside)
        popup.addSubview(restartButton)
        
        view.addSubview(popup)
    }
    
    @objc private func restartGame() {
        newGame()
        view.subviews.last?.removeFromSuperview() // Remove the restart popup
    }
}

class CustomPopupView: UIView {
    
    let messageLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        label.textAlignment = .center
        label.textColor = .white
        label.numberOfLines = 0
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    private func setupView() {
        backgroundColor = UIColor.black.withAlphaComponent(0.8)
        layer.cornerRadius = 10
        
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(messageLabel)
        
        NSLayoutConstraint.activate([
            messageLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            messageLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            messageLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            messageLabel.topAnchor.constraint(equalTo: topAnchor, constant: 10),
            messageLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -10)
        ])
    }
}
