import UIKit

class ColorMemoryGameViewController: UIViewController {
    
    // UI Elements
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Color Memory Game"
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    private let scoreLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 20)
        label.textAlignment = .center
        label.textColor = .white
        label.text = "Coins: 1000"
        return label
    }()
    
    private let instructionLabel: UILabel = {
        let label = UILabel()
        label.text = "Memorize the sequence!"
        label.numberOfLines = 0
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 20, weight: .regular)
        label.textAlignment = .center
        return label
    }()
    
    private var colorButtons: [UIButton] = []
    private var colors: [UIColor] = [.red, .green, .blue]
    private var sequence: [UIColor] = []
    private var playerSequence: [UIColor] = []
    private var score: Int = 1000
    
    private let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Game", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.layer.cornerRadius = 10
        button.backgroundColor = UIColor.systemBlue
        button.tintColor = .white
        return button
    }()
    
    // Custom Popup View
    private let resultPopup: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        view.layer.cornerRadius = 12
        return view
    }()
    
    private let resultLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    private let restartButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Restart", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.layer.cornerRadius = 10
        button.backgroundColor = UIColor.systemGreen
        button.tintColor = .white
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        score = loadCoins()
        if score == 0 {
            score = 1000
            saveCoins(score)
        }
        scoreLabel.text = "Coins: \(score)"
        setupUI()
        setupButtons()
        startButton.addTarget(self, action: #selector(startGame), for: .touchUpInside)
        restartButton.addTarget(self, action: #selector(restartGame), for: .touchUpInside)
    }
    
    private func setupUI() {
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        scoreLabel.translatesAutoresizingMaskIntoConstraints = false
        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
        startButton.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(titleLabel)
        view.addSubview(scoreLabel)
        view.addSubview(instructionLabel)
        view.addSubview(startButton)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            scoreLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20),
            scoreLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            instructionLabel.topAnchor.constraint(equalTo: scoreLabel.bottomAnchor, constant: 20),
            instructionLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            instructionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            instructionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            startButton.topAnchor.constraint(equalTo: instructionLabel.bottomAnchor, constant: 20),
            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            startButton.widthAnchor.constraint(equalToConstant: 200),
            startButton.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        setupResultPopup()
    }
    
    private func setupButtons() {
        let buttonWidth: CGFloat = 100
        let buttonHeight: CGFloat = 100
        let spacing: CGFloat = 20
        
        for color in colors {
            let button = UIButton(type: .system)
            button.backgroundColor = color
            button.layer.cornerRadius = 10
            button.addTarget(self, action: #selector(colorButtonTapped(_:)), for: .touchUpInside)
            colorButtons.append(button)
            view.addSubview(button)
        }
        
        for (index, button) in colorButtons.enumerated() {
            button.translatesAutoresizingMaskIntoConstraints = false
            
            NSLayoutConstraint.activate([
                button.widthAnchor.constraint(equalToConstant: buttonWidth),
                button.heightAnchor.constraint(equalToConstant: buttonHeight),
                button.topAnchor.constraint(equalTo: startButton.bottomAnchor, constant: 40 + CGFloat(index) * (buttonHeight + spacing)),
                button.centerXAnchor.constraint(equalTo: view.centerXAnchor)
            ])
        }
    }
    
    private func setupResultPopup() {
        resultPopup.translatesAutoresizingMaskIntoConstraints = false
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        restartButton.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(resultPopup)
        resultPopup.addSubview(resultLabel)
        resultPopup.addSubview(restartButton)
        
        NSLayoutConstraint.activate([
            resultPopup.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            resultPopup.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            resultPopup.widthAnchor.constraint(equalToConstant: 250),
            resultPopup.heightAnchor.constraint(equalToConstant: 150),
            
            resultLabel.topAnchor.constraint(equalTo: resultPopup.topAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: resultPopup.leadingAnchor, constant: 16),
            resultLabel.trailingAnchor.constraint(equalTo: resultPopup.trailingAnchor, constant: -16),
            resultLabel.heightAnchor.constraint(equalToConstant: 30),
            
            restartButton.topAnchor.constraint(equalTo: resultLabel.bottomAnchor, constant: 20),
            restartButton.centerXAnchor.constraint(equalTo: resultPopup.centerXAnchor),
            restartButton.widthAnchor.constraint(equalToConstant: 100),
            restartButton.heightAnchor.constraint(equalToConstant: 40)
        ])
        
        resultPopup.isHidden = true
    }
    
    @objc private func startGame() {
        if score < 100 {
            showAlert("Not Enough Coins", "You need at least 100 coins to play.")
            return
        }
        sequence.removeAll()
        playerSequence.removeAll()
        scoreLabel.text = "Coins: \(score)"
        instructionLabel.text = "Memorize the sequence!"
        
        let randomColor = colors.randomElement()!
        sequence.append(randomColor)
        
        showSequence()
    }
    
    private func showSequence() {
        for (index, color) in sequence.enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index)) {
                self.colorButtons[self.colors.firstIndex(of: color)!].alpha = 0.5
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.colorButtons[self.colors.firstIndex(of: color)!].alpha = 1.0
                }
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + Double(sequence.count) + 0.5) {
            self.instructionLabel.text = "Repeat the sequence!"
        }
    }
    
    @objc private func colorButtonTapped(_ sender: UIButton) {
        guard let buttonIndex = colorButtons.firstIndex(of: sender) else { return }
        playerSequence.append(colors[buttonIndex])
        
        if playerSequence.count == sequence.count {
            checkSequence()
        }
    }
    
    private func checkSequence() {
        if playerSequence == sequence {
            score += 100
            scoreLabel.text = "Coins: \(score)"
            instructionLabel.text = "Correct! Get ready for the next sequence!"
            playerSequence.removeAll()
            
            let randomColor = colors.randomElement()!
            sequence.append(randomColor)
            
            if sequence.count >= 5 {
                score += 1000
                saveCoins(score)
                showResultPopup(won: true)
            } else {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    self.showSequence()
                }
            }
        } else {
            score -= 100
            saveCoins(score)
            scoreLabel.text = "Coins: \(score)"
            instructionLabel.text = "Wrong! Game over!"
            playerSequence.removeAll()
            showResultPopup(won: false)
        }
    }
    
    private func showResultPopup(won: Bool) {
        resultPopup.isHidden = false
        resultLabel.text = won ? "You Win!\n+1000 Coins!" : "You Lose!\n-100 Coins!"
        
        // Hide color buttons during popup
        colorButtons.forEach { $0.isHidden = true }
        
        resultPopup.alpha = 0
        resultPopup.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
        
        UIView.animate(withDuration: 0.3) {
            self.resultPopup.alpha = 1
            self.resultPopup.transform = .identity
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            UIView.animate(withDuration: 0.3, animations: {
                self.resultPopup.alpha = 0
                self.resultPopup.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
            }) { _ in
                self.resultPopup.isHidden = true
                self.resultPopup.transform = .identity
                
                // Show color buttons again
                self.colorButtons.forEach { $0.isHidden = false }
                
                if self.score < 100 {
                    self.restartGame()
                }
            }
        }
    }
    
    @objc private func restartGame() {
        score = 1000
        saveCoins(score)
        scoreLabel.text = "Coins: \(score)"
        instructionLabel.text = "Start a new game!"
        sequence.removeAll()
        playerSequence.removeAll()
        resultPopup.isHidden = true
        colorButtons.forEach { $0.isHidden = false }
    }
    
    private func showAlert(_ title: String, _ message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    private func saveCoins(_ coins: Int) {
        UserDefaults.standard.set(coins, forKey: "coins")
    }
    
    private func loadCoins() -> Int {
        return UserDefaults.standard.integer(forKey: "coins")
    }
}
