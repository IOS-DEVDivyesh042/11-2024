import UIKit

class TriviaGameViewController: UIViewController {
    
    private let questions: [(question: String, answers: [String], correctIndex: Int)] = [
        ("What is the capital of France?", ["Paris", "London", "Berlin", "Madrid"], 0),
        ("What is 2 + 2?", ["3", "4", "5", "6"], 1),
        ("What color is the sky?", ["Green", "Blue", "Red", "Yellow"], 1),
        ("Who wrote 'Hamlet'?", ["Shakespeare", "Dickens", "Hemingway", "Austen"], 0),
        ("What is the largest planet?", ["Earth", "Mars", "Jupiter", "Saturn"], 2),
        ("What is the boiling point of water?", ["100°C", "90°C", "80°C", "110°C"], 0),
        ("What is the main ingredient in guacamole?", ["Tomato", "Avocado", "Pepper", "Onion"], 1),
        ("What is the currency of Japan?", ["Yen", "Dollar", "Euro", "Won"], 0),
        ("Who painted the Mona Lisa?", ["Van Gogh", "Da Vinci", "Picasso", "Rembrandt"], 1),
        ("What is the capital of Italy?", ["Rome", "Venice", "Florence", "Milan"], 0),
        ("What gas do plants absorb?", ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"], 1),
        ("What is the smallest continent?", ["Asia", "Antarctica", "Europe", "Australia"], 3),
        ("How many continents are there?", ["5", "6", "7", "8"], 2),
        ("What is the hardest natural substance on Earth?", ["Gold", "Iron", "Diamond", "Quartz"], 2),
        ("What is the square root of 64?", ["6", "7", "8", "9"], 2),
        ("Who discovered gravity?", ["Einstein", "Newton", "Galileo", "Copernicus"], 1),
        ("What is the capital of the USA?", ["New York", "Washington D.C.", "Los Angeles", "Chicago"], 1),
        ("Which planet is known as the Red Planet?", ["Earth", "Venus", "Mars", "Jupiter"], 2),
        ("What is the largest mammal?", ["Elephant", "Blue Whale", "Giraffe", "Hippopotamus"], 1),
        ("What is H2O commonly known as?", ["Oxygen", "Hydrogen", "Water", "Salt"], 2),
        ("What is the main language spoken in Brazil?", ["Spanish", "Portuguese", "English", "French"], 1)
    ]
    
    private var currentQuestionIndex = 0
    private var correctAnswersCount = 0
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Trivia Game"
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textAlignment = .center
        label.textColor = .white
        return label
    }()
    
    private let questionLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 20)
        label.numberOfLines = 0
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    private let coinLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        label.textAlignment = .center
        label.textColor = .white
        label.text = "Coins: 0"
        return label
    }()
    
    private var answerButtons: [UIButton] = []
    
    private let resultPopup: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        view.layer.cornerRadius = 12
        view.isHidden = true
        return view
    }()
    
    private let resultLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    private let restartButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Restart", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.layer.cornerRadius = 10
        button.backgroundColor = UIColor.systemGreen
        button.tintColor = .white
        return button
    }()
    
    private let homeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Go to Home", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.layer.cornerRadius = 10
        button.backgroundColor = UIColor.systemBlue
        button.tintColor = .white
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        let currentCoins = UserDefaults.standard.integer(forKey: "coins")
        coinLabel.text = "Total Coins: \(currentCoins)"
        setupUI()
        loadQuestion()
        
        restartButton.addTarget(self, action: #selector(restartGame), for: .touchUpInside)
        homeButton.addTarget(self, action: #selector(goToHome), for: .touchUpInside)
    }
    
    private func setupUI() {
        view.addSubview(titleLabel)
        view.addSubview(questionLabel)
        view.addSubview(coinLabel)
        
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        questionLabel.translatesAutoresizingMaskIntoConstraints = false
        coinLabel.translatesAutoresizingMaskIntoConstraints = false
        
        for _ in 0..<4 {
            let button = UIButton(type: .system)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
            button.layer.cornerRadius = 10
            button.backgroundColor = UIColor.systemOrange
            button.tintColor = .white
            button.addTarget(self, action: #selector(answerButtonTapped(_:)), for: .touchUpInside)
            answerButtons.append(button)
            view.addSubview(button)
            button.translatesAutoresizingMaskIntoConstraints = false
        }
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            questionLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20),
            questionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            questionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
        
        for (index, button) in answerButtons.enumerated() {
            NSLayoutConstraint.activate([
                button.topAnchor.constraint(equalTo: questionLabel.bottomAnchor, constant: CGFloat(50 + (index * 60))),
                button.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                button.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
                button.heightAnchor.constraint(equalToConstant: 50)
            ])
        }
        
        NSLayoutConstraint.activate([
            coinLabel.topAnchor.constraint(equalTo: answerButtons.last!.bottomAnchor, constant: 30),
            coinLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            coinLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            coinLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
        
        setupResultPopup()
    }
    
    private func setupResultPopup() {
        resultPopup.translatesAutoresizingMaskIntoConstraints = false
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        restartButton.translatesAutoresizingMaskIntoConstraints = false
        homeButton.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(resultPopup)
        resultPopup.addSubview(resultLabel)
        resultPopup.addSubview(restartButton)
        resultPopup.addSubview(homeButton)
        
        NSLayoutConstraint.activate([
            resultPopup.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            resultPopup.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            resultPopup.widthAnchor.constraint(equalToConstant: 300),
            resultPopup.heightAnchor.constraint(equalToConstant: 200),
            
            resultLabel.topAnchor.constraint(equalTo: resultPopup.topAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: resultPopup.leadingAnchor, constant: 16),
            resultLabel.trailingAnchor.constraint(equalTo: resultPopup.trailingAnchor, constant: -16),
            resultLabel.heightAnchor.constraint(equalToConstant: 60),
            
            restartButton.topAnchor.constraint(equalTo: resultLabel.bottomAnchor, constant: 20),
            restartButton.centerXAnchor.constraint(equalTo: resultPopup.centerXAnchor),
            restartButton.widthAnchor.constraint(equalToConstant: 150),
            restartButton.heightAnchor.constraint(equalToConstant: 40),
            
            homeButton.topAnchor.constraint(equalTo: restartButton.bottomAnchor, constant: 10),
            homeButton.centerXAnchor.constraint(equalTo: resultPopup.centerXAnchor),
            homeButton.widthAnchor.constraint(equalToConstant: 150),
            homeButton.heightAnchor.constraint(equalToConstant: 40)
        ])
    }
    
    private func loadQuestion() {
        if currentQuestionIndex < questions.count {
            let currentQuestion = questions[currentQuestionIndex]
            questionLabel.text = currentQuestion.question
            for (index, button) in answerButtons.enumerated() {
                button.setTitle(currentQuestion.answers[index], for: .normal)
            }
        } else {
            showResult()
        }
    }
    
    @objc private func answerButtonTapped(_ sender: UIButton) {
        guard let buttonIndex = answerButtons.firstIndex(of: sender) else { return }
        let currentQuestion = questions[currentQuestionIndex]
        
        if buttonIndex == currentQuestion.correctIndex {
            correctAnswersCount += 1
        }
        
        currentQuestionIndex += 1
        loadQuestion()
    }
    
    private func showResult() {
        let totalCoins = correctAnswersCount * 50
        let currentCoins = UserDefaults.standard.integer(forKey: "coins")
        let newTotal = currentCoins + totalCoins
        UserDefaults.standard.set(newTotal, forKey: "coins")
        
        resultLabel.text = "Quiz Complete!\n\nCorrect Answers: \(correctAnswersCount)\nCoins Earned: +\(totalCoins)"
        coinLabel.text = "Total Coins: \(newTotal)"
        
        answerButtons.forEach { $0.isHidden = true }
        questionLabel.isHidden = true
        
        resultPopup.isHidden = false
        resultPopup.alpha = 0
        resultPopup.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
        
        UIView.animate(withDuration: 0.3) {
            self.resultPopup.alpha = 1
            self.resultPopup.transform = .identity
        }
    }
    
    @objc private func restartGame() {
        currentQuestionIndex = 0
        correctAnswersCount = 0
        resultPopup.isHidden = true
        
        answerButtons.forEach { $0.isHidden = false }
        questionLabel.isHidden = false
        
        loadQuestion()
    }
    
    @objc private func goToHome() {
        dismiss(animated: true)
    }
}
