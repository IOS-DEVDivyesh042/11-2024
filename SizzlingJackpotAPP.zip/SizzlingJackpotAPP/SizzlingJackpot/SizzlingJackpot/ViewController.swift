import UIKit

class ViewController: UIViewController {
    
    // UI Elements
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Stone-Paper-Scissors"
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textAlignment = .center
        label.textColor = .white
        return label
    }()
    
    private let playerImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.layer.borderColor = UIColor.white.cgColor
        imageView.layer.borderWidth = 2
        return imageView
    }()
    
    private let computerImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.layer.borderColor = UIColor.white.cgColor
        imageView.layer.borderWidth = 2
        return imageView
    }()
    
    private let resultLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.textAlignment = .center
        label.textColor = .black
        label.numberOfLines = 0
        label.text = "Choose your move!"
        return label
    }()
    
    private let coinLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.textAlignment = .center
        label.textColor = .black
        return label
    }()
    
    private let stoneButton = UIButton(type: .system)
    private let paperButton = UIButton(type: .system)
    private let scissorsButton = UIButton(type: .system)
    
    // Available moves and images
    private let moves = ["Stone", "Paper", "Scissors"]
    private let images = [
        "Stone": UIImage(named: "stone"),
        "Paper": UIImage(named: "paper"),
        "Scissors": UIImage(named: "scissors")
    ]
    
    private var coins: Int {
        get {
            return UserDefaults.standard.integer(forKey: "coins")
        }
        set {
            UserDefaults.standard.set(newValue, forKey: "coins")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        coins = 1000 // Initialize coins to 1000
        updateCoinLabel()
    }
    
    private func setupUI() {
        // Configure title label
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)
        
        // Configure image views
        playerImageView.translatesAutoresizingMaskIntoConstraints = false
        computerImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(playerImageView)
        view.addSubview(computerImageView)
        
        // Configure buttons
        setupButton(stoneButton, title: "Stone")
        setupButton(paperButton, title: "Paper")
        setupButton(scissorsButton, title: "Scissors")
        
        // Configure result label
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(resultLabel)

        // Configure coin label
        coinLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(coinLabel)

        // Layout constraints
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            playerImageView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 40),
            playerImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            playerImageView.widthAnchor.constraint(equalToConstant: 120),
            playerImageView.heightAnchor.constraint(equalToConstant: 120),
            
            computerImageView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 40),
            computerImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            computerImageView.widthAnchor.constraint(equalToConstant: 120),
            computerImageView.heightAnchor.constraint(equalToConstant: 120),
            
            stoneButton.topAnchor.constraint(equalTo: playerImageView.bottomAnchor, constant: 50),
                   stoneButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
                   stoneButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
                   stoneButton.heightAnchor.constraint(equalToConstant: 50), // Optional: Set button height
                   
                   paperButton.topAnchor.constraint(equalTo: stoneButton.bottomAnchor, constant: 20),
                   paperButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
                   paperButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
                   paperButton.heightAnchor.constraint(equalToConstant: 50),
                   
                   scissorsButton.topAnchor.constraint(equalTo: paperButton.bottomAnchor, constant: 20),
                   scissorsButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
                   scissorsButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
                   scissorsButton.heightAnchor.constraint(equalToConstant: 50),
            
            resultLabel.topAnchor.constraint(equalTo: scissorsButton.bottomAnchor, constant: 40),
            resultLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            resultLabel.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            
            coinLabel.topAnchor.constraint(equalTo: resultLabel.bottomAnchor, constant: 20),
            coinLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    private func setupButton(_ button: UIButton, title: String) {
        button.setTitle(title, for: .normal)
        button.tintColor = .white
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        button.backgroundColor = UIColor.systemOrange // Set the background color to system orange
        button.layer.cornerRadius = 10 // Optional: Add a corner radius for rounded edges
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(playerMoveSelected(_:)), for: .touchUpInside)
        view.addSubview(button)
    }

    
    @objc private func playerMoveSelected(_ sender: UIButton) {
        guard let playerMove = sender.title(for: .normal) else { return }
        animateImageViews(playerMove: playerMove)
    }
    
    private func animateImageViews(playerMove: String) {
        // Safely unwrap images for the animation
        let animationImages = [images["Stone"], images["Paper"], images["Scissors"]].compactMap { $0 }
//        playerImageView.animationImages = animationImages
//        computerImageView.animationImages = animationImages
        playerImageView.animationDuration = 0.5
        computerImageView.animationDuration = 0.5
        playerImageView.startAnimating()
        computerImageView.startAnimating()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.playerImageView.stopAnimating()
            self.computerImageView.stopAnimating()
            
            // Set the final images for player and computer
            self.playerImageView.image = self.images[playerMove] ?? nil
            let computerMove = self.moves.randomElement()!
            self.computerImageView.image = self.images[computerMove] ?? nil
            
            // Determine the result
            let result = self.determineWinner(playerMove: playerMove, computerMove: computerMove)
            self.resultLabel.text = """
            You chose: \(playerMove)
            Computer chose: \(computerMove)
            """
            
            self.handleGameResult(result: result)
        }
    }
    
    private func determineWinner(playerMove: String, computerMove: String) -> String {
        if playerMove == computerMove {
            return "Tie"
        }
        
        switch (playerMove, computerMove) {
        case ("Stone", "Scissors"), ("Scissors", "Paper"), ("Paper", "Stone"):
            return "Win"
        default:
            return "Lose"
        }
    }

    private func handleGameResult(result: String) {
        if result == "Win" {
            coins += 1000 // Add 1000 coins for win
            showCustomPopup(message: "You Win! +1000 coins!")
        } else if result == "Lose" {
            coins -= 100 // Deduct 100 coins for loss
            showCustomPopup(message: "You Lose! -100 coins!")
        } else {
            showCustomPopup(message: "It's a Tie!")
        }
        updateCoinLabel()
    }
    
    private func updateCoinLabel() {
        coinLabel.text = "Coins: \(coins)"
    }

    private func showCustomPopup(message: String) {
        let popupView = UIView()
        popupView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        popupView.layer.cornerRadius = 10
        popupView.translatesAutoresizingMaskIntoConstraints = false
        
        let messageLabel = UILabel()
        messageLabel.text = message
        messageLabel.textColor = .white
        messageLabel.textAlignment = .center
        messageLabel.numberOfLines = 0
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        
        popupView.addSubview(messageLabel)
        view.addSubview(popupView)

        // Layout constraints for popup
        NSLayoutConstraint.activate([
            popupView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            popupView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            popupView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            popupView.heightAnchor.constraint(greaterThanOrEqualToConstant: 100),

            messageLabel.topAnchor.constraint(equalTo: popupView.topAnchor, constant: 20),
            messageLabel.leadingAnchor.constraint(equalTo: popupView.leadingAnchor, constant: 20),
            messageLabel.trailingAnchor.constraint(equalTo: popupView.trailingAnchor, constant: -20),
            messageLabel.bottomAnchor.constraint(equalTo: popupView.bottomAnchor, constant: -20)
        ])

        // Animate the popup appearance
        popupView.alpha = 0
        UIView.animate(withDuration: 0.3) {
            popupView.alpha = 1
        }

        // Dismiss the popup after a few seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            UIView.animate(withDuration: 0.3, animations: {
                popupView.alpha = 0
            }) { _ in
                popupView.removeFromSuperview()
            }
        }
    }
}
