import UIKit

class ViewController: UIViewController {
    
    // UI Elements
    var amountTextField: UITextField!
    var fromCurrencyPicker: UIPickerView!
    var toCurrencyPicker: UIPickerView!
    var convertButton: UIButton!
    var resultLabel: UILabel!
    
    let currencies = CryptoConverter.getAllCryptos()
    
    var selectedFromCurrency: String = "bitcoin"
    var selectedToCurrency: String = "ethereum"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        // Set up the UI components
        setupUI()
    }
    
    func setupUI() {
        // Set up amountTextField
        amountTextField = UITextField()
        amountTextField.borderStyle = .roundedRect
        amountTextField.placeholder = "Enter amount"
        amountTextField.keyboardType = .decimalPad
        amountTextField.layer.cornerRadius = 8
        amountTextField.layer.shadowColor = UIColor.gray.cgColor
        amountTextField.layer.shadowOpacity = 0.5
        amountTextField.layer.shadowOffset = CGSize(width: 2, height: 2)
        amountTextField.layer.shadowRadius = 4
        amountTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(amountTextField)
        
        // Set up fromCurrencyPicker
        fromCurrencyPicker = UIPickerView()
        fromCurrencyPicker.delegate = self
        fromCurrencyPicker.dataSource = self
        fromCurrencyPicker.layer.cornerRadius = 8
        fromCurrencyPicker.layer.shadowColor = UIColor.gray.cgColor
        fromCurrencyPicker.layer.shadowOpacity = 0.5
        fromCurrencyPicker.layer.shadowOffset = CGSize(width: 2, height: 2)
        fromCurrencyPicker.layer.shadowRadius = 4
        fromCurrencyPicker.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(fromCurrencyPicker)
        
        // Set up toCurrencyPicker
        toCurrencyPicker = UIPickerView()
        toCurrencyPicker.delegate = self
        toCurrencyPicker.dataSource = self
        toCurrencyPicker.layer.cornerRadius = 8
        toCurrencyPicker.layer.shadowColor = UIColor.gray.cgColor
        toCurrencyPicker.layer.shadowOpacity = 0.5
        toCurrencyPicker.layer.shadowOffset = CGSize(width: 2, height: 2)
        toCurrencyPicker.layer.shadowRadius = 4
        toCurrencyPicker.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toCurrencyPicker)
        
        // Set up convertButton
        convertButton = UIButton(type: .system)
        convertButton.setTitle("Convert", for: .normal)
        convertButton.backgroundColor = .gray
        convertButton.setTitleColor(.white, for: .normal)
        convertButton.layer.cornerRadius = 8
        convertButton.layer.shadowColor = UIColor.gray.cgColor
        convertButton.layer.shadowOpacity = 0.5
        convertButton.layer.shadowOffset = CGSize(width: 2, height: 2)
        convertButton.layer.shadowRadius = 4
        convertButton.addTarget(self, action: #selector(convertAction), for: .touchUpInside)
        convertButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(convertButton)
        
        // Set up resultLabel
        resultLabel = UILabel()
        resultLabel.text = "Result will be displayed here."
        resultLabel.numberOfLines = 0
        resultLabel.textAlignment = .center
        resultLabel.layer.cornerRadius = 8
        resultLabel.layer.masksToBounds = true
        resultLabel.layer.shadowColor = UIColor.gray.cgColor
        resultLabel.layer.shadowOpacity = 0.5
        resultLabel.layer.shadowOffset = CGSize(width: 2, height: 2)
        resultLabel.layer.shadowRadius = 4
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(resultLabel)
        
        // Add constraints for UI components
        NSLayoutConstraint.activate([
            amountTextField.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
            amountTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            amountTextField.widthAnchor.constraint(equalToConstant: 250),
            amountTextField.heightAnchor.constraint(equalToConstant: 40),
            
            fromCurrencyPicker.topAnchor.constraint(equalTo: amountTextField.bottomAnchor, constant: 20),
            fromCurrencyPicker.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            fromCurrencyPicker.heightAnchor.constraint(equalToConstant: 100),
            
            toCurrencyPicker.topAnchor.constraint(equalTo: fromCurrencyPicker.bottomAnchor, constant: 20),
            toCurrencyPicker.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            toCurrencyPicker.heightAnchor.constraint(equalToConstant: 100),
            
            convertButton.topAnchor.constraint(equalTo: toCurrencyPicker.bottomAnchor, constant: 20),
            convertButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            convertButton.widthAnchor.constraint(equalToConstant: 150),
            convertButton.heightAnchor.constraint(equalToConstant: 40),
            
            resultLabel.topAnchor.constraint(equalTo: convertButton.bottomAnchor, constant: 20),
            resultLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            resultLabel.widthAnchor.constraint(equalToConstant: 300),
            resultLabel.bottomAnchor.constraint(lessThanOrEqualTo: view.bottomAnchor, constant: -100)
        ])
    }
    
    @objc func convertAction() {
        guard let amountText = amountTextField.text, let amount = Double(amountText), amount > 0 else {
            resultLabel.text = "Please enter a valid amount."
            return
        }
        
        // Perform conversion using CryptoConverter
        if let convertedAmount = CryptoConverter.convert(amount: amount, from: selectedFromCurrency, to: selectedToCurrency) {
            resultLabel.text = "\(amount) \(selectedFromCurrency) is \(convertedAmount) \(selectedToCurrency)"
        } else {
            resultLabel.text = "Conversion failed. Please try again."
        }
    }
}

extension ViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return currencies.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return currencies[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == fromCurrencyPicker {
            selectedFromCurrency = currencies[row]
        } else if pickerView == toCurrencyPicker {
            selectedToCurrency = currencies[row]
        }
    }
}
