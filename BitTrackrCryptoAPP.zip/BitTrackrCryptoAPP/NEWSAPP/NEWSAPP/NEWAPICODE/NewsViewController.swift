import UIKit

class NewsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var tableView: UITableView!
    var articles: [Article] = []
    let cellSpacingHeight: CGFloat = 5
    
    // Define the set to track favorite articles
    var favoriteArticles: Set<Int> = [] // Set to store the indices of favorite articles

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupTableView()
        fetchNews()
    }
    
    func setupTableView() {
        tableView = UITableView(frame: view.bounds, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.showsVerticalScrollIndicator = false
        tableView.separatorStyle = .none
        tableView.register(ArticleTableViewCell.self, forCellReuseIdentifier: "ArticleCell")
        tableView.backgroundColor = .clear
        tableView.contentInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
        view.addSubview(tableView)
    }
    
    func fetchNews() {
        guard let url = URL(string: "https://newsapi.org/v2/everything?q=apple&from=2024-11-24&to=2024-11-24&sortBy=popularity&apiKey=1a7db84dd5764fdca255565efaf31955") else {
            print("Invalid URL")
            return
        }

        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
                return
            }

            guard let data = data else {
                print("No data received")
                return
            }

            do {
                let decoder = JSONDecoder()
                let newsResponse = try decoder.decode(NewsResponse.self, from: data)
                DispatchQueue.main.async {
                    // Filter out articles with title "[Removed]"
                    self?.articles = newsResponse.articles?.filter { $0.title != "[Removed]" } ?? []
                    self?.tableView.reloadData()
                }
            } catch {
                print("Error decoding data: \(error)")
            }
        }

        task.resume()
    }

    // MARK: - Table View DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articles.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ArticleCell", for: indexPath) as! ArticleTableViewCell
        let article = articles[indexPath.row]
        
        cell.titleLabel.text = article.title ?? "No Title"
        
        // Set the button state based on whether the article is in favoriteArticles set
        cell.starButton.isSelected = favoriteArticles.contains(indexPath.row)
        
        cell.starButton.addTarget(self, action: #selector(starTapped(_:)), for: .touchUpInside)
        cell.starButton.tag = indexPath.row
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let article = articles[indexPath.row]
        print("Selected article: \(article.title ?? "No Title")")
    }
    
    @objc func starTapped(_ sender: UIButton) {
        let articleIndex = sender.tag
        let isCurrentlyFavorite = favoriteArticles.contains(articleIndex)
        
        // Show an alert to toggle "Mark as Read/Unread"
        let alert = UIAlertController(
            title: isCurrentlyFavorite ? "Mark as Unread" : "Mark as Read",
            message: "Do you want to mark this article as \(isCurrentlyFavorite ? "unread" : "read")?",
            preferredStyle: .alert
        )
        
        let confirmAction = UIAlertAction(title: "Yes", style: .default) { [weak self] _ in
            if isCurrentlyFavorite {
                self?.favoriteArticles.remove(articleIndex)
                sender.isSelected = false
            } else {
                self?.favoriteArticles.insert(articleIndex)
                sender.isSelected = true
            }
        }
        
        let cancelAction = UIAlertAction(title: "No", style: .cancel, handler: nil)
        
        alert.addAction(confirmAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
}
