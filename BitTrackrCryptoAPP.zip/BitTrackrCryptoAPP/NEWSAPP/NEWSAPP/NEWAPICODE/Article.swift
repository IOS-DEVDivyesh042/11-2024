////
////  Models.swift
////  NEWSAPP
////
////  Created by Shubham Parekh on 23/11/24.
////
//
//import Foundation
//
//
//struct NewsResponse: Codable {
//    let status: String
//    let totalResults: Int? // Make totalResults optional
//    let articles: [Article]?
//}
//
//
//struct Article: Codable,Equatable {
//    static func == (lhs: Article, rhs: Article) -> Bool {
//        <#code#>
//    }
//    
//    let source: Source
//    let author: String?
//    let title: String?
//    let description: String?
//    let url: String?
//    let urlToImage: String?
//    let publishedAt: String?
//    let content: String?
//}
//
//struct Source: Codable {
//    let id: String?
//    let name: String
//}
//
import Foundation

struct NewsResponse: Codable {
    let status: String
    let totalResults: Int? // Make totalResults optional
    let articles: [Article]?
}

struct Article: Codable, Equatable {
    static func == (lhs: Article, rhs: Article) -> Bool {
        // Articles are considered equal if their titles and publication dates match
        return lhs.title == rhs.title && lhs.publishedAt == rhs.publishedAt
    }
    
    let source: Source
    let author: String?
    let title: String?
    let description: String?
    let url: String?
    let urlToImage: String?
    let publishedAt: String?
    let content: String?
}

struct Source: Codable {
    let id: String?
    let name: String
}
