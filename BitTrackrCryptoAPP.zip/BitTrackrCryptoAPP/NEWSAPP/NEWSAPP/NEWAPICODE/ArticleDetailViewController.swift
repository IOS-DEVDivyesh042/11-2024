import UIKit

class ArticleDetailViewController: UIViewController {

    private let article: Article

    private let scrollView = UIScrollView()
    private let contentView = UIView()

    private let imageView = UIImageView()
    private let descriptionLabel = UILabel()
    private let authorLabel = UILabel()
    private let contentLabel = UILabel()
    private let urlButton = UIButton(type: .system)
    
    // Loader (Activity Indicator)
    private let loader = UIActivityIndicatorView(style: .large)

    init(article: Article) {
        self.article = article
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    func setupUI() {
      //  view.backgroundColor = .black

        // ScrollView Setup
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor)
        ])

        // ImageView
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        contentView.addSubview(imageView)

        // Loader (Activity Indicator)
        loader.translatesAutoresizingMaskIntoConstraints = false
        loader.hidesWhenStopped = true
        loader.startAnimating() // Start the loader
        contentView.addSubview(loader)

        // Description Label
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.text = article.description ?? "No Description"
        descriptionLabel.textColor = .white
        descriptionLabel.numberOfLines = 0
        descriptionLabel.font = UIFont.systemFont(ofSize: 18, weight: .regular)
        contentView.addSubview(descriptionLabel)

        // Author Label
        authorLabel.translatesAutoresizingMaskIntoConstraints = false
        authorLabel.text = "Author: \(article.author ?? "Unknown")"
        authorLabel.textColor = .white
        authorLabel.font = UIFont.systemFont(ofSize: 16, weight: .light)
        contentView.addSubview(authorLabel)

        // Content Label
        contentLabel.translatesAutoresizingMaskIntoConstraints = false
        contentLabel.text = article.content ?? "No Content"
        contentLabel.textColor = .white
        contentLabel.numberOfLines = 0
        contentLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        contentView.addSubview(contentLabel)

//        // URL Button
//        urlButton.translatesAutoresizingMaskIntoConstraints = false
//        urlButton.setTitle(article.url ?? "No URL", for: .normal)
//        urlButton.setTitleColor(.systemBlue, for: .normal)
//        urlButton.addTarget(self, action: #selector(openURL), for: .touchUpInside)
//        contentView.addSubview(urlButton)

        // Constraints for the loader
        NSLayoutConstraint.activate([
            loader.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            loader.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            loader.heightAnchor.constraint(equalToConstant: 50),
            loader.widthAnchor.constraint(equalToConstant: 50)
        ])

        // Constraints for other UI elements
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imageView.heightAnchor.constraint(equalToConstant: 250),

            descriptionLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 16),
            descriptionLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            descriptionLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

            authorLabel.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 16),
            authorLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            authorLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

            contentLabel.topAnchor.constraint(equalTo: authorLabel.bottomAnchor, constant: 16),
            contentLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            contentLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

//            urlButton.topAnchor.constraint(equalTo: contentLabel.bottomAnchor, constant: 16),
//            urlButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
//            urlButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
//            urlButton.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -16)
        ])
        
        // Fetch Image and hide loader once image is loaded
        if let urlToImage = article.urlToImage, let url = URL(string: urlToImage) {
            fetchImage(from: url) { [weak self] image in
                DispatchQueue.main.async {
                    if let image = image {
                        self?.imageView.image = image
                    }
                    self?.loader.stopAnimating() // Stop the loader when the image is loaded
                }
            }
        }
    }

    @objc func openURL() {
        if let urlString = article.url, let url = URL(string: urlString) {
            UIApplication.shared.open(url)
        }
    }

    func fetchImage(from url: URL, completion: @escaping (UIImage?) -> Void) {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                completion(UIImage(data: data))
            } else {
                completion(nil)
            }
        }
        task.resume()
    }
}
