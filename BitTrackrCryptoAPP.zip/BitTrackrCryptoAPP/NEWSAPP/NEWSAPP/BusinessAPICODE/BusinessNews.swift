//
//  NewsResponse.swift
//  NEWSAPP
//
//  Created by Shubham Parekh on 23/11/24.
//

import Foundation



struct BusinessNews: Codable {
    let articles: [BusinessArticle]
}

struct BusinessArticle: Codable {
    let author: String?
    let title: String
    let description: String?  // Optional, can be nil
    let url: String?
    let urlToImage: String?
    let publishedAt: String
    let content: String? // Optional

    // Custom initializer for decoding
    enum CodingKeys: String, CodingKey {
        case author
        case title
        case description
        case url
        case urlToImage
        case publishedAt
        case content
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        author = try container.decodeIfPresent(String.self, forKey: .author)
        title = try container.decode(String.self, forKey: .title)
        description = try container.decodeIfPresent(String.self, forKey: .description)
        url = try container.decodeIfPresent(String.self, forKey: .url)
        urlToImage = try container.decodeIfPresent(String.self, forKey: .urlToImage)
        publishedAt = try container.decode(String.self, forKey: .publishedAt)
        content = try container.decodeIfPresent(String.self, forKey: .content)
    }
}

