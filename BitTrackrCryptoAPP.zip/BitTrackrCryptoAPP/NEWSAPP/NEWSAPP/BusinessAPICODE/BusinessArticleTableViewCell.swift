import UIKit

class BusinessArticleTableViewCell: UITableViewCell {

    var titleLabel: UILabel!
    var descriptionLabel: UILabel!
    var authorLabel: UILabel!
    var publishedAtLabel: UILabel!
    var starButton: UIButton!
    var containerView: UIView!

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(containerView)

        // Apply shadow and corner radius to containerView
        containerView.layer.shadowColor = UIColor.black.cgColor
        containerView.layer.shadowOpacity = 0.1
        containerView.layer.shadowOffset = CGSize(width: 0, height: 2)
        containerView.layer.shadowRadius = 4
        containerView.layer.cornerRadius = 10  // Apply corner radius to container

        // Title Label
        titleLabel = UILabel()
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.font = UIFont.boldSystemFont(ofSize: 18)
        titleLabel.numberOfLines = 0
        containerView.addSubview(titleLabel)

        // Description Label
        descriptionLabel = UILabel()
        descriptionLabel.numberOfLines = 0
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.font = UIFont.systemFont(ofSize: 14)
        containerView.addSubview(descriptionLabel)

        // Author Label
        authorLabel = UILabel()
        authorLabel.numberOfLines = 0
        authorLabel.translatesAutoresizingMaskIntoConstraints = false
        authorLabel.font = UIFont.italicSystemFont(ofSize: 12)
        containerView.addSubview(authorLabel)

        // Published At Label
        publishedAtLabel = UILabel()
        publishedAtLabel.numberOfLines = 0
        publishedAtLabel.translatesAutoresizingMaskIntoConstraints = false
        publishedAtLabel.font = UIFont.systemFont(ofSize: 12)
        publishedAtLabel.textColor = .gray
        containerView.addSubview(publishedAtLabel)

        // Star Button
        starButton = UIButton(type: .system)
        starButton.translatesAutoresizingMaskIntoConstraints = false
        starButton.setImage(UIImage(systemName: "star"), for: .normal)
        starButton.setImage(UIImage(systemName: "star.fill"), for: .selected)
        containerView.addSubview(starButton)

        // Auto Layout Constraints
        NSLayoutConstraint.activate([
            // Container view constraints (with margin of 10 from all edges)
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10),
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),

            // Title label constraints
            titleLabel.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 10),
            titleLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),

            // Description label constraints
            descriptionLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 5),
            descriptionLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 10),
            descriptionLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),

            // Author label constraints
            authorLabel.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 5),
            authorLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 10),
            authorLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),

            // Published at label constraints
            publishedAtLabel.topAnchor.constraint(equalTo: authorLabel.bottomAnchor, constant: 5),
            publishedAtLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 10),
            publishedAtLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),

            // Star button constraints (positioned at bottom-right with a 50-point margin from the trailing edge)
            starButton.topAnchor.constraint(equalTo: publishedAtLabel.bottomAnchor, constant: 10),
            starButton.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),
            starButton.widthAnchor.constraint(equalToConstant: 30),
            starButton.heightAnchor.constraint(equalToConstant: 30)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
