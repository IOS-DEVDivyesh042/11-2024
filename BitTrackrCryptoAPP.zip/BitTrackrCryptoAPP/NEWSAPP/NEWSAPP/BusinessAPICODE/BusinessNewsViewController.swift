import UIKit

class BusinessNewsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var tableView: UITableView!
    var articles: [BusinessArticle] = []
    var favoriteArticles: Set<Int> = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTableView()
        fetchBusinessNews()
    }
    
    func setupTableView() {
        tableView = UITableView(frame: view.bounds, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .singleLine
        tableView.register(BusinessArticleTableViewCell.self, forCellReuseIdentifier: "ArticleCell")
        view.addSubview(tableView)
    }

    func fetchBusinessNews() {
        guard let url = URL(string: "https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=1a7db84dd5764fdca255565efaf31955") else {
            print("Invalid URL")
            return
        }

        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
                return
            }

            guard let data = data else {
                print("No data received")
                return
            }

            do {
                let decoder = JSONDecoder()
                let newsResponse = try decoder.decode(BusinessNews.self, from: data)
                DispatchQueue.main.async {
                    // Filter out articles with title "[Removed]"
                    self?.articles = newsResponse.articles.filter { $0.title != "[Removed]" }
                    self?.tableView.reloadData()
                }
            } catch {
                print("Error decoding data: \(error)")
            }
        }
        task.resume()
    }

    // MARK: - TableView DataSource and Delegate

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articles.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ArticleCell", for: indexPath) as! BusinessArticleTableViewCell

        let article = articles[indexPath.row]
        cell.titleLabel.text = article.title
        cell.descriptionLabel.text = article.description
        cell.authorLabel.text = article.author ?? "Unknown Author"
        cell.publishedAtLabel.text = article.publishedAt
        cell.contentView.backgroundColor = .clear
        cell.starButton.isSelected = favoriteArticles.contains(indexPath.row)
        cell.starButton.tag = indexPath.row
        cell.starButton.addTarget(self, action: #selector(starTapped(_:)), for: .touchUpInside)

        cell.containerView.layer.cornerRadius = 10
        cell.containerView.layer.shadowColor = UIColor.gray.cgColor
        cell.containerView.layer.shadowOpacity = 0.4
        cell.containerView.layer.shadowRadius = 6
        cell.containerView.layer.shadowOffset = CGSize(width: 0, height: 3)
        
        cell.starButton.isUserInteractionEnabled = true
        //cell.isUserInteractionEnabled = false
        cell.selectionStyle = .none
        return cell
    }

    @objc func starTapped(_ sender: UIButton) {
        let index = sender.tag
        var alertMessage: String
        
        if favoriteArticles.contains(index) {
            // Article is marked as favorite (read)
            favoriteArticles.remove(index)
            sender.isSelected = false
            alertMessage = "Marked as Unread"
        } else {
            // Article is not marked as favorite (unread)
            favoriteArticles.insert(index)
            sender.isSelected = true
            alertMessage = "Marked as Read"
        }
        
        // Show an alert with the appropriate message
        let alert = UIAlertController(title: "Article Status", message: alertMessage, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
}
