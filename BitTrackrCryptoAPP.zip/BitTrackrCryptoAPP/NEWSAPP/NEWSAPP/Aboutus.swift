import UIKit

class Aboutus: UIViewController {

    let aboutTextView = UITextView()

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        
        // Setup the UITextView
        setupTextView()
    }

    func setupTextView() {
        // Set the properties for the text view
        aboutTextView.translatesAutoresizingMaskIntoConstraints = false
        aboutTextView.layer.cornerRadius = 10
        aboutTextView.layer.shadowColor = UIColor.black.cgColor
        aboutTextView.layer.shadowOffset = CGSize(width: 0, height: 2)
        aboutTextView.layer.shadowRadius = 5
        aboutTextView.layer.shadowOpacity = 0.3
        aboutTextView.layer.masksToBounds = false
        
        // Optionally set the text inside the text view
        aboutTextView.text = "About Us – BitTrackr CryptoWelcome to BitTrackr Crypto, your ultimate destination for staying ahead of the rapidly evolving world of cryptocurrency. We understand that the crypto landscape can be overwhelming, with constant market fluctuations, new technologies, and daily updates. That's why we created BitTrackr Crypto – to simplify the world of crypto for enthusiasts, investors, and beginners alike.Our app offers real-time news, insights, and analysis on the latest happenings in the world of blockchain, cryptocurrencies, and decentralized finance. Whether you're tracking Bitcoin’s latest price surge, learning about emerging altcoins, or exploring innovations in DeFi, BitTrackr Crypto ensures you stay informed and make educated decisions.We bring you news from reliable sources, breaking stories, and in-depth articles about market trends, crypto regulations, and blockchain technology. BitTrackr Crypto also allows you to monitor your favorite coins and tokens, track price movements, and receive personalized alerts, so you never miss an important update.Our mission is to empower you with knowledge and tools that allow you to navigate the fast-paced crypto market with confidence. We are committed to delivering up-to-the-minute updates, ensuring you have access to the most relevant and accurate information at your fingertips.At BitTrackr Crypto, we believe that education and transparency are key to making informed choices in the world of cryptocurrency. Join us as we explore the future of finance and track the latest developments in the crypto space together."

        // Add the text view to the view hierarchy
        view.addSubview(aboutTextView)

        // Set AutoLayout constraints
        NSLayoutConstraint.activate([
            aboutTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            aboutTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -100),
            aboutTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            aboutTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }
}
