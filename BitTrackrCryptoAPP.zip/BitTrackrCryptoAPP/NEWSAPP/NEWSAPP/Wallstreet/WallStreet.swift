import Foundation

class WallStreet: Decodable {
    var title: String
    var description: String
    var author: String?
    var publishedAt: String?
    var urlToImage: String?

    enum CodingKeys: String, CodingKey {
        case title
        case description
        case author
        case publishedAt
        case urlToImage
    }

    // Custom initializer to handle null values
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        title = try container.decode(String.self, forKey: .title)
        description = (try? container.decode(String.self, forKey: .description)) ?? "" // Default to empty string if null
        author = try? container.decode(String.self, forKey: .author)
        publishedAt = try? container.decode(String.self, forKey: .publishedAt)
        urlToImage = try? container.decode(String.self, forKey: .urlToImage)
    }
}
struct ArticlesResponse: Decodable {
    var articles: [WallStreet]
}
