import UIKit

class WallStreetArticleTableViewCell: UITableViewCell {

    var articleImageView: UIImageView!
    var titleLabel: UILabel!
    var descriptionLabel: UILabel!
    var authorLabel: UILabel!
    var publishedAtLabel: UILabel!
    var containerView: UIView!

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(containerView)

        // Apply corner radius and shadow to the container
        containerView.layer.cornerRadius = 10
        containerView.layer.borderWidth = 4
        containerView.layer.borderColor = UIColor.black.cgColor
        containerView.layer.shadowColor = UIColor.black.cgColor
        containerView.layer.shadowOpacity = 0.2
        containerView.layer.shadowRadius = 4
        containerView.layer.shadowOffset = CGSize(width: 0, height: 2)

        // ImageView (top section)
        articleImageView = UIImageView()
        articleImageView.translatesAutoresizingMaskIntoConstraints = false
        articleImageView.layer.cornerRadius = 20
        articleImageView.layer.masksToBounds = true
        containerView.addSubview(articleImageView)

        // Title Label
        titleLabel = UILabel()
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.font = UIFont.boldSystemFont(ofSize: 18)
        titleLabel.numberOfLines = 0
        containerView.addSubview(titleLabel)

        // Description Label
        descriptionLabel = UILabel()
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.numberOfLines = 0
        containerView.addSubview(descriptionLabel)

        // Author Label
        authorLabel = UILabel()
        authorLabel.translatesAutoresizingMaskIntoConstraints = false
        authorLabel.font = UIFont.italicSystemFont(ofSize: 12)
        authorLabel.textColor = .gray
        containerView.addSubview(authorLabel)

        // Published Date Label
        publishedAtLabel = UILabel()
        publishedAtLabel.translatesAutoresizingMaskIntoConstraints = false
        publishedAtLabel.font = UIFont.systemFont(ofSize: 12)
        publishedAtLabel.textColor = .gray
        containerView.addSubview(publishedAtLabel)

        // Auto Layout Constraints
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10),
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),

            articleImageView.topAnchor.constraint(equalTo: containerView.topAnchor),
            articleImageView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
            articleImageView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
            articleImageView.heightAnchor.constraint(equalToConstant: 150),

            titleLabel.topAnchor.constraint(equalTo: articleImageView.bottomAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 10),
            titleLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),

            descriptionLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 5),
            descriptionLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 10),
            descriptionLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),

            authorLabel.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 5),
            authorLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 10),
            authorLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),

            publishedAtLabel.topAnchor.constraint(equalTo: authorLabel.bottomAnchor, constant: 5),
            publishedAtLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 10),
            publishedAtLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure(with article: WallStreet) {
        titleLabel.text = article.title
        descriptionLabel.text = article.description

        if let author = article.author {
            authorLabel.text = "By \(author)"
        } else {
            authorLabel.isHidden = true
        }

        // Convert `publishedAt` string to `Date` safely
        if let publishedDateString = article.publishedAt, let publishedDate = DateFormatter.localizedDate(from: publishedDateString) {
            publishedAtLabel.text = DateFormatter.shortDateString(from: publishedDate)
        } else {
            publishedAtLabel.isHidden = true
        }

        if let imageUrlString = article.urlToImage, let imageUrl = URL(string: imageUrlString) {
            articleImageView.loadImage(from: imageUrl)
        } else {
            articleImageView.isHidden = true
        }
    }
}

extension DateFormatter {
    static func localizedDate(from string: String) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        return dateFormatter.date(from: string)
    }

    static func shortDateString(from date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        return dateFormatter.string(from: date)
    }
}

extension UIImageView {
    func loadImage(from url: URL) {
        DispatchQueue.global().async {
            if let data = try? Data(contentsOf: url) {
                DispatchQueue.main.async {
                    self.image = UIImage(data: data)
                }
            }
        }
    }
}
