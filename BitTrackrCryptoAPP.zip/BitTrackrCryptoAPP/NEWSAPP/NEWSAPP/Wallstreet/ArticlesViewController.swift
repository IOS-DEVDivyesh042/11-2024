import UIKit

class ArticlesViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {

    var articles: [WallStreet] = [] // Array to hold the articles
    var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()

       // tableView.showsVerticalScrollIndicator = false
        // Set up the table view
        tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(WallStreetArticleTableViewCell.self, forCellReuseIdentifier: "WallStreetArticleCell")
        tableView.dataSource = self
        view.addSubview(tableView)
 
        tableView.delegate = self
        // Auto Layout for table view
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])

        // Fetch the data from the API
        fetchArticles()
    }

    func fetchArticles() {
        guard let url = URL(string: "https://newsapi.org/v2/everything?domains=wsj.com&apiKey=1a7db84dd5764fdca255565efaf31955") else { return }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                do {
                    // Decode the JSON response into ArticlesResponse
                    let response = try JSONDecoder().decode(ArticlesResponse.self, from: data)
                    DispatchQueue.main.async {
                        self.articles = response.articles // Set the articles array
                        self.tableView.reloadData() // Reload table view
                    }
                } catch {
                    print("Error decoding response: \(error)")
                }
            }
        }
        task.resume()
    }

    // TableView DataSource methods

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articles.count // Return the count of articles
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WallStreetArticleCell", for: indexPath) as! WallStreetArticleTableViewCell
        let article = articles[indexPath.row]  // Get the specific article
        cell.configure(with: article)  // Pass the article to the configure method
        cell.backgroundColor = .clear
          cell.contentView.backgroundColor = .clear
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 450
    }

}
