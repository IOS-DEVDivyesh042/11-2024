import UIKit

class CryptoListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let tableView = UITableView()
    let cryptoOptions = [
        "BTC", "ETH", "ADA", "BNB", "SOL", "XRP", "DOGE", "DOT", "MATIC", "LTC",
        "AVAX", "UNI", "ATOM", "LINK", "XLM", "TRX", "SHIB", "NEAR", "ALGO", "AAVE",
        "FTM", "HBAR", "ICP", "EOS", "VET", "XTZ", "FIL", "MANA", "SAND", "AXS"
    ]
    
    // Dictionary to store descriptions for each cryptocurrency
    let cryptoDescriptions = [
        "BTC": "The first decentralized cryptocurrency.",
        "ETH": "A platform for decentralized smart contracts.",
        "ADA": "Blockchain for decentralized apps.",
        "BNB": "Native coin of Binance exchange.",
        "SOL": "Scalable blockchain for dApps.",
        "XRP": "Currency for Ripple's payment network.",
        "DOGE": "A meme-based cryptocurrency.",
        "DOT": "Enables blockchain interoperability.",
        "MATIC": "Ethereum Layer 2 scaling solution.",
        "LTC": "A lighter alternative to Bitcoin.",
        "AVAX": "Fast blockchain for smart contracts.",
        "UNI": "Token of the Uniswap exchange.",
        "ATOM": "Interoperable blockchain for dApps.",
        "LINK": "Oracle solution for smart contracts.",
        "XLM": "Fast payments for global transfers.",
        "TRX": "Blockchain platform for entertainment content.",
        "SHIB": "A meme cryptocurrency like Dogecoin.",
        "NEAR": "Developer-friendly blockchain for apps.",
        "ALGO": "A scalable blockchain for fast transactions.",
        "AAVE": "Decentralized finance lending protocol.",
        "FTM": "High-performance blockchain for dApps.",
        "HBAR": "Token for Hedera Hashgraph network.",
        "ICP": "Blockchain for scalable web apps.",
        "EOS": "Blockchain platform for smart contracts.",
        "VET": "Supply chain-focused blockchain.",
        "XTZ": "Blockchain for decentralized governance.",
        "FIL": "Token for decentralized storage.",
        "MANA": "Token for Decentraland metaverse.",
        "SAND": "Token for Sandbox metaverse.",
        "AXS": "Gaming token for Axie Infinity."
    ]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Cryptocurrency List"
        view.backgroundColor = .white
        
        setupTableView()
    }
    
    func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cryptoCell")
     //   tableView.rowHeight = 100  // Increased row height to accommodate description
        tableView.separatorStyle = .none
        tableView.backgroundColor = .clear
        tableView.showsVerticalScrollIndicator = false
        
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    // MARK: Table View DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cryptoOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cryptoCell", for: indexPath)
        let cryptoSymbol = cryptoOptions[indexPath.row]
        cell.backgroundColor = .clear
          cell.contentView.backgroundColor = .clear
        // Customize cell appearance
        let containerView = UIView()
        containerView.layer.cornerRadius = 10
        containerView.layer.borderWidth = 1
        containerView.layer.borderColor = UIColor.lightGray.cgColor
        containerView.layer.shadowColor = UIColor.gray.cgColor
        containerView.layer.shadowOpacity = 0.5
        containerView.layer.shadowOffset = CGSize(width: 0, height: 2)
        containerView.layer.shadowRadius = 4
        containerView.backgroundColor = .white
        
        let label = UILabel()
        label.text = cryptoSymbol
        label.textAlignment = .center
        label.font = UIFont.boldSystemFont(ofSize: 20)
        
        let descriptionLabel = UILabel()
        descriptionLabel.text = cryptoDescriptions[cryptoSymbol] ?? "No description available."
        descriptionLabel.textAlignment = .center
        descriptionLabel.font = UIFont.systemFont(ofSize: 14)
        descriptionLabel.textColor = .gray
        descriptionLabel.numberOfLines = 0
        
        containerView.addSubview(label)
        containerView.addSubview(descriptionLabel)
        
        label.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            label.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 10),
            descriptionLabel.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            descriptionLabel.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 5),
            descriptionLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 10),
            descriptionLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),
            descriptionLabel.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -10)
        ])
        
        cell.contentView.addSubview(containerView)
        containerView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 10),
            containerView.leadingAnchor.constraint(equalTo: cell.contentView.leadingAnchor, constant: 10),
            containerView.trailingAnchor.constraint(equalTo: cell.contentView.trailingAnchor, constant: -10),
            containerView.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -10)
        ])
        
        return cell
    }
    
    // MARK: Table View Delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedCrypto = cryptoOptions[indexPath.row]
        let chartVC = CryptoChartViewController()
        chartVC.cryptoSymbol = selectedCrypto
        navigationController?.pushViewController(chartVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}
