import UIKit
import Charts

class CryptoChartViewController: UIViewController {

    var cryptoSymbol: String?
    let candlestickChartView = CandleStickChartView()
    let currency = "USD"
    let apiKey = "cd0dad1e1ada89389e2ca199f0a747277432acd88a4697eab86cea5811f385f0"

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = cryptoSymbol ?? "Crypto Chart"
        setupChartView()
        
        if let symbol = cryptoSymbol {
            fetchHistoricalData(for: symbol)
        }
    }

    func setupChartView() {
        candlestickChartView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(candlestickChartView)
        
        NSLayoutConstraint.activate([
            candlestickChartView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            candlestickChartView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            candlestickChartView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            candlestickChartView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16)
        ])
    }

    func fetchHistoricalData(for symbol: String) {
        let urlString = "https://min-api.cryptocompare.com/data/v2/histoday?fsym=\(symbol)&tsym=\(currency)&limit=30&api_key=\(apiKey)"
        
        guard let url = URL(string: urlString) else { return }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                print("Error fetching data: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                   let data = json["Data"] as? [String: Any],
                   let prices = data["Data"] as? [[String: Any]] {
                    
                    var entries: [CandleChartDataEntry] = []

                    for (index, priceData) in prices.enumerated() {
                        if let open = priceData["open"] as? Double,
                           let high = priceData["high"] as? Double,
                           let low = priceData["low"] as? Double,
                           let close = priceData["close"] as? Double {
                            let entry = CandleChartDataEntry(x: Double(index), shadowH: high, shadowL: low, open: open, close: close)
                            entries.append(entry)
                        }
                    }

                    DispatchQueue.main.async {
                        self.updateChart(with: entries)
                    }
                }
            } catch {
                print("Failed to parse JSON: \(error.localizedDescription)")
            }
        }
        
        task.resume()
    }

    func updateChart(with entries: [CandleChartDataEntry]) {
        let dataSet = CandleChartDataSet(entries: entries, label: "Price")
        dataSet.colors = [.black]
        dataSet.increasingColor = .green
        dataSet.increasingFilled = true
        dataSet.decreasingColor = .red
        dataSet.decreasingFilled = true
        dataSet.shadowColorSameAsCandle = true

        candlestickChartView.data = CandleChartData(dataSet: dataSet)
    }
}
