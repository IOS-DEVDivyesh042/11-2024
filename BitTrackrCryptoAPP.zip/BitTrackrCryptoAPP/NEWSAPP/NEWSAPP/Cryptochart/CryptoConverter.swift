//
//  CryptoConverter.swift
//  NEWSAPP
//
//  Created by Shubham Parekh on 23/11/24.
//

import Foundation


struct CryptoConverter {
    // Static dictionary for storing conversion rates to USD
    static let rates: [String: Double] = [
        "bitcoin": 50000.0,      // 1 Bitcoin = 50,000 USD
        "ethereum": 4000.0,      // 1 Ethereum = 4,000 USD
        "litecoin": 200.0,       // 1 Litecoin = 200 USD
        "ripple": 1.0,           // 1 Ripple = 1 USD
        "dogecoin": 0.08         // 1 Dogecoin = 0.08 USD
    ]
    
    static func convertToUSD(amount: Double, currency: String) -> Double? {
        guard let rate = rates[currency] else { return nil }
        return amount * rate
    }
    
    static func convert(amount: Double, from: String, to: String) -> Double? {
        guard let fromRate = rates[from], let toRate = rates[to] else { return nil }
        let amountInUSD = amount * fromRate
        return amountInUSD / toRate
    }
    
    static func getRate(for currency: String) -> Double? {
        return rates[currency]
    }
    
    static func getAllCryptos() -> [String] {
        return Array(rates.keys)
    }
}
