//
//  HomeVCTableViewCell.swift
//  NEWSAPP
//
//  Created by Shubham Parekh on 24/11/24.
//

import UIKit

class HomeVCTableViewCell: UITableViewCell {
    @IBOutlet weak var newsImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(with image: UIImage) {
           newsImageView.image = image
       }

}
