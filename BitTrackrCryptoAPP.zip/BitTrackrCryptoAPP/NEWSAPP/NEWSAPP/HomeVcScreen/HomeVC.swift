//
//  HomeVC.swift
//  NEWSAPP
//
//  Created by Shubham Parekh on 24/11/24.
//

import StoreKit
import UIKit

class HomeVC: UIViewController{
   
    let images: [String] = [
           "bussiness", "WallStreet", "Crypto", "Journal",
           "Converter", "Rate", "Aboutus"
       ]
    
    @IBOutlet weak var tblhomeVC: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tblhomeVC.delegate = self
        tblhomeVC.dataSource = self
        
        
    }

}


extension HomeVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return images.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! HomeVCTableViewCell
        let imageName = images[indexPath.row]
               cell.configure(with: UIImage(named: imageName)!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        if indexPath.row == 0 {
            // Navigate to BusinessViewController
            let businessVC = BusinessNewsViewController()
            businessVC.title = "Business"
            navigationController?.pushViewController(businessVC, animated: true)
        } else if indexPath.row == 1 {
            // Navigate to WallStreetViewController
            let wallStreetVC = ArticlesViewController()
            wallStreetVC.title = "Wall Street"
            navigationController?.pushViewController(wallStreetVC, animated: true)
        } else if indexPath.row == 2 {
            // Navigate to CryptoViewController
            let cryptoVC = CryptoListViewController()
            cryptoVC.title = "Crypto"
            navigationController?.pushViewController(cryptoVC, animated: true)
        } else if indexPath.row == 3 {
            // Navigate to JournalViewController
            let journalVC = NewsViewController()
            journalVC.title = "Journal"
            navigationController?.pushViewController(journalVC, animated: true)
        } else if indexPath.row == 4 {
            // Navigate to ConverterViewController
            let converterVC = ViewController()
            converterVC.title = "Converter"
            navigationController?.pushViewController(converterVC, animated: true)
        } else if indexPath.row == 5 {
            // Navigate to RateViewController
            if let windowScene = view.window?.windowScene { SKStoreReviewController.requestReview(in: windowScene) }
            // Navigate to FeedbackViewController
//            let feedbackVC = FeedbackVC()
//            feedbackVC.title = "Feedback"
//            navigationController?.pushViewController(feedbackVC, animated: true)
        } else if indexPath.row == 6 {
            let Aboutus = Aboutus()
            Aboutus.title = "Feedback"
            navigationController?.pushViewController(Aboutus, animated: true)

        } else if indexPath.row == 7 {
            // Navigate to AboutUsViewController
           
          

//            let newsVC = Aboutus()
//            let navigationController = UINavigationController(rootViewController: newsVC)
          

//            let aboutUsVC = Aboutus()
//            aboutUsVC.title = "About Us"
//            navigationController?.pushViewController(aboutUsVC, animated: true)
        }
    }

    
    
}
